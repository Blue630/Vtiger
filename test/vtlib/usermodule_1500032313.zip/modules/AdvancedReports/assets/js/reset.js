//reset ugly default stuff that breaks things
(function(){
    var saver = document.createElement("iframe");
    saver.src = "about:blank";
    document.body.appendChild(saver);
    var prototype = saver.contentWindow.Array.prototype;
    var fns = ["concat","toString", "toLocaleString", "join", "pop", "push",
        "reverse", "shift", "unshift", "slice", "splice",
        "sort", "filter", "forEach", "some", "every", "map",
        "indexOf", "lastIndexOf", "reduce", "reduceRight"];
    for (var i = 0; i < fns.length; ++i) {
        var fnName = fns[i];
        var fn = prototype[fnName];
        if (fn) {
            Array.prototype[fnName] = fn;
        }
    }
    document.body.removeChild(saver);

}());
document.getElementsByClassName = HTMLDocument.prototype.getElementsByClassName;
