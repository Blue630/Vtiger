<?php
/**
* Dependencies
*/


class AdvancedReports_ReportBuilder_View extends Vtiger_Index_View
{
	public function process(Vtiger_Request $request)
	{
		$moduleName = $request->getModule();
		$smarty = $this->getViewer($request);
		$adb = PearDatabase::getInstance();
		include "modules/AdvancedReports/reportBuilder.php";
		if($_REQUEST['parenttab'] == "settings"){
			$smarty->view('ReportBuilder/settings.tpl', $moduleName);
		}else{
			$smarty->view('ReportBuilder/main.tpl', $moduleName);
		}

	}
}




