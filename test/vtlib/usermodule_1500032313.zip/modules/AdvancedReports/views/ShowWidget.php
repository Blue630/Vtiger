<?php
class AdvancedReports_ShowWidget_View extends Vtiger_IndexAjax_View{
    public function process(Vtiger_Request $request){
        $content = "";//either iframe with report OR picklist
        $title = "";//either "pick report" or report title
        $linkId = (int)$_REQUEST['linkid'];
        $widgetId = (int)$_REQUEST['widgetid'];
        $contentOnly = isset($_REQUEST['refresh'])?(1):(0);
        $adb = PearDatabase::getInstance();
        $reportId = null;
        $r = $adb->query("SELECT `data`,`title` FROM vtiger_module_dashboard_widgets WHERE id=".$widgetId);
        if($r){
            $r = $r->GetAll();
            $reportId = (int)$r[0]['data'];
            $title = $r[0]['title'];
        }
        if(!$reportId){
            $content = "Pick report: <select></select>";
        }else{
            $content = '<iframe style="height:100%;width:100%;border:0px;" src="index.php?module=AdvancedReports&view=AdvancedReportsAjax&file=widget&record='.$reportId.'" />';
        }

        if($contentOnly){
            echo $content;
            return;
        }
        $refreshLink = "index.php?module=AdvancedReports&view=ShowWidget&name=widget&linkid=".$linkId."&widgetid=".$widgetId."&refresh=1";//if exists
        $deleteLink = "index.php?module=Vtiger&action=RemoveWidget&linkid=".$linkId."&widgetid=".$widgetId;
        echo '<div class="dashboardWidgetHeader">
    <table width="100%" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
            <th class="span4">
                <div class="dashboardTitle" title="'.$title.'"><b>&nbsp;&nbsp;'.$title.'</b></div>
            </th>
            <th class="refresh span1" align="right">
                <span style="position:relative;"></span>
            </th>
            <th class="widgeticons span5" align="right">
                <a href="javascript:void(0);" name="drefresh" data-url="'.$refreshLink.'">
                    <i class="icon-refresh" hspace="2" border="0" align="absmiddle" title="'.vtranslate('LBL_REFRESH').'" alt="'.vtranslate('LBL_REFRESH').'"></i>
                </a>
                <a name="dclose" class="widget" data-url="'.$deleteLink.'">
                        <i class="icon-remove" hspace="2" border="0" align="absmiddle" title="'.vtranslate('LBL_REMOVE').'" alt="'.vtranslate('LBL_REMOVE').'"></i>
                </a>
            </th>
        </tr>
        </thead>
    </table>
</div>
<div class="dashboardWidgetContent">

'.$content.'

</div>';
        return;
    }
}