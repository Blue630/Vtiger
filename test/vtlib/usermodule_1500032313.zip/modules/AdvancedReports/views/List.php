<?php
class AdvancedReports_List_View extends Vtiger_Index_View{

    public function process(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $smarty = $this->getViewer($request);
        $adb = PearDatabase::getInstance();
        include "modules/AdvancedReports/index.php";
        $smarty->view('ReportViewer/main.tpl', $moduleName);
    }

    // #4047 [start] - Added custom footer
	public function postProcess(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$viewer = $this->viewer;
		$currentUser = Users_Record_Model::getCurrentUserModel();
		$viewer->assign('ACTIVITY_REMINDER', $currentUser->getCurrentUserActivityReminderInSeconds());
		// Define custom footer for right javascripts
		$viewer->view('ReportViewer/Footer.tpl', $moduleName);
	}
	// #4047 [end]

}