<?php
class AdvancedReports_AdvancedReportsAjax_View extends Vtiger_IndexAjax_View{
    protected function validFile($name){
        $r = false;
        if(preg_match("/^[a-zA-Z]{1,}$/",$name)){//no dots, avoid directory traversal attacks
            $r = true;
        }
        return $r;
    }
    public function process(Vtiger_Request $request){
        $file = $request->get("file");
        if(!empty($file) && $this->validFile($file)) {
            include "modules/AdvancedReports/".$file.".php";//worst thing that can happen is that no file exists and it trows an error
            return;
        }
    }
}