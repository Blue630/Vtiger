<?php

class AdvancedReports_Settings_View extends Vtiger_Index_View{
    public function process(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $smarty = $this->getViewer($request);

        include "modules/AdvancedReports/settings.php";


        $smarty->view('ReportViewer/settings.tpl', $moduleName);
    }
}