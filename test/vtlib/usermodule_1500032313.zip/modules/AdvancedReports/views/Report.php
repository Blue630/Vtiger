<?php
class AdvancedReports_Report_View extends AdvancedReports_List_View{
    public function process(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $smarty = $this->getViewer($request);
        $adb = PearDatabase::getInstance();
        include "modules/AdvancedReports/report.php";
        $smarty->view('ReportViewer/report.tpl', $moduleName);
    }
}