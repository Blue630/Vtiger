<?php



// #5854 - Store custom versions (YetiForce) on installation
function isCustomVtigerVersion() {
	global $YetiForce_current_version;
	if(!empty($YetiForce_current_version)) {
		return true;
	}

	return false;
}

/**
* Dependencies
*/
// #5854 - Some custom vtiger version have different file locations
if(isCustomVtigerVersion()) {
	require_once 'include/CRMEntity.php';
	require_once 'include/Tracker.php';
} else {
	require_once 'data/CRMEntity.php';
	require_once 'data/Tracker.php';
}


/**
* Advanced Reports main module file
*/
class AdvancedReports extends CRMentity {

	/**
	* Constructor
	*/
	function AdvancedReports() {
	}

	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($modulename, $event_type) {
		if($event_type == 'module.postinstall') {
			// TODO Handle post installation actions
			// #5854 - Some custom vtiger version database adapters doesn't allow to use transaction, etc. SQL methods
			if(!isCustomVtigerVersion()) {
				$this->importSQLFromFile();	
			}
			

			//#4031 [start] - generate language files
			global $adb;

			$qry_result =  $adb->pquery("SELECT prefix FROM vtiger_language", array());
			$res_cnt = $adb->num_rows($qry_result);
			if($res_cnt > 0) {
				for($i=0;$i<$res_cnt;$i++) {
					$prefix = $adb->query_result($qry_result,$i,"prefix");
					$filename = "languages/".$prefix."/AdvancedReports.php";
					if (!file_exists($filename)) {
						if(file_exists("languages/en_us/AdvancedReports.php")){
							copy("languages/en_us/AdvancedReports.php", $filename);
						}
					}
				}
			}
			//#4031 [end]
		
			// Register link
			$moduleInstance = Vtiger_Module::getInstance('AdvancedReports');
			$moduleInstance->addLink(
				'DASHBOARDWIDGET', 
				'Advanced Reporting Widget', 
				'index.php?module=AdvancedReports&view=ShowWidget&name=widget', 
				null,
				-1,
				null);
			global $adb;
			$adb->dieOnError = false;
			$adb->debug = false;
			// #5854 - Some custom vtiger version database adapters doesn't allow to use following SQL methods
			if(!isCustomVtigerVersion()) {
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_g` (`id` int(11) NOT NULL,`group` int(11) NOT NULL,UNIQUE KEY `report_idx` (`id`,`group`), KEY `group` (`group`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_r` (`id` int(11) NOT NULL,`role` varchar(255) NOT NULL,UNIQUE KEY `report_idx` (`id`,`role`),KEY `role` (`role`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_u` (`id` int(11) NOT NULL,`user` int(11) NOT NULL,UNIQUE KEY `report_idx` (`id`,`user`),KEY `user` (`user`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
			$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_config` (`key` varchar(32) DEFAULT NULL,`value` text, UNIQUE KEY `key` (`key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_g` ADD CONSTRAINT `vtiger_advancedreports_schedule_g_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_g_ibfk_2` FOREIGN KEY (`group`) REFERENCES `vtiger_groups` (`groupid`)");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_r` ADD CONSTRAINT `vtiger_advancedreports_schedule_r_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_r_ibfk_2` FOREIGN KEY (`role`) REFERENCES `vtiger_role` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_u`ADD CONSTRAINT `vtiger_advancedreports_schedule_u_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_u_ibfk_2` FOREIGN KEY (`user`) REFERENCES `vtiger_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule` ADD `formats` BLOB NULL DEFAULT NULL");
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `labels` LONGBLOB NOT NULL AFTER `options`"); // #4544
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `visible` INT(1) NOT NULL DEFAULT '1'"); // #4947
				$adb->query("ALTER TABLE `vtiger_advancedreports_categories` ADD `visible` INT(1) NOT NULL DEFAULT '1'"); // #4947
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `calcFields` BLOB NULL DEFAULT NULL"); // #5098
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `columnstate` BLOB NULL DEFAULT NULL"); // #5098
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule` ADD `emails` BLOB NULL DEFAULT NULL"); // #5872
			}
			
            // Init config data
            $this->initConfig($adb);
            $this->cleanup();
		} else if($event_type == 'module.disabled') {
			// TODO Handle actions when this module is disabled.
		} else if($event_type == 'module.enabled') {
			// TODO Handle actions when this module is enabled.
		} else if($event_type == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($event_type == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($event_type == 'module.postupdate') {
			// TODO Handle actions after this module is updated.
			global $adb;
			$adb->dieOnError = false;
			$adb->debug = false;
			// #5854 - Some custom vtiger version database adapters doesn't allow to use following SQL methods
			if(!isCustomVtigerVersion()) {
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_g` (`id` int(11) NOT NULL,`group` int(11) NOT NULL,UNIQUE KEY `report_idx` (`id`,`group`), KEY `group` (`group`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_r` (`id` int(11) NOT NULL,`role` varchar(255) NOT NULL,UNIQUE KEY `report_idx` (`id`,`role`),KEY `role` (`role`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
				$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_schedule_u` (`id` int(11) NOT NULL,`user` int(11) NOT NULL,UNIQUE KEY `report_idx` (`id`,`user`),KEY `user` (`user`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 ");
			$adb->query("CREATE TABLE IF NOT EXISTS `vtiger_advancedreports_config` (`key` varchar(32) DEFAULT NULL,`value` text, UNIQUE KEY `key` (`key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_g` ADD CONSTRAINT `vtiger_advancedreports_schedule_g_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_g_ibfk_2` FOREIGN KEY (`group`) REFERENCES `vtiger_groups` (`groupid`)");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_r` ADD CONSTRAINT `vtiger_advancedreports_schedule_r_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_r_ibfk_2` FOREIGN KEY (`role`) REFERENCES `vtiger_role` (`roleid`) ON DELETE CASCADE ON UPDATE CASCADE");
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule_u`ADD CONSTRAINT `vtiger_advancedreports_schedule_u_ibfk_1` FOREIGN KEY (`id`) REFERENCES `vtiger_advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,ADD CONSTRAINT `vtiger_advancedreports_schedule_u_ibfk_2` FOREIGN KEY (`user`) REFERENCES `vtiger_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE");
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `labels` LONGBLOB NOT NULL AFTER `options`"); // #4544
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `visible` INT(1) NOT NULL DEFAULT '1'"); // #4947
				$adb->query("ALTER TABLE `vtiger_advancedreports_categories` ADD `visible` INT(1) NOT NULL DEFAULT '1'"); // #4947
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `calcFields` BLOB NULL DEFAULT NULL"); // #5098
				$adb->query("ALTER TABLE `vtiger_advancedreports` ADD `columnstate` BLOB NULL DEFAULT NULL"); // #5098
				$adb->query("ALTER TABLE `vtiger_advancedreports_schedule` ADD `emails` BLOB NULL DEFAULT NULL"); // #5872
			}

            // Init config data
            $this->initConfig($adb);
            $this->cleanup();

			//#4594 [start] - generate missing strings in language files
			global $adb;
			$qry_result =  $adb->pquery("SELECT prefix FROM vtiger_language", array());
			$res_cnt = $adb->num_rows($qry_result);
			if($res_cnt > 0) {
				for($i=0;$i<$res_cnt;$i++) {
					$languages[] = $prefix = $adb->query_result($qry_result,$i,"prefix");
				}
			}
			$eng = $this->getTranslationsInLang("en_us");
			foreach ($languages as $lang){
				$translated = $this->getTranslationsInLang($lang);
				$update = false;
				foreach ($eng as $string => $v) {
					if(!isset($translated[$string])){
						$translated[$string] = $v;
						$update = true;
					}
				}
				if($update){
					$string = '<'.'?php $languageStrings = '.var_export($translated,true).';';
					file_put_contents("languages/".$lang."/AdvancedReports.php", $string);
				}
			}
	    	
		}
	}
	function getTranslationsInLang($lang){
		include "languages/".$lang."/AdvancedReports.php";
		return $languageStrings;
	}
	//#4594 [end]

	/**
	 * Import base data into AdvancedReports table from import.sql
	 */
	function importSQLFromFile($filename = false) {
		global $adb;

		if(!$filename) {
			$filename = dirname(__FILE__) . '/import.sql';
		}

		// Check for file existence
		if(!file_exists($filename)) {
			echo "<b>File $filename doesn't exist. Cancelling SQL data import!</b>\n<br/>";
			return;
		}

		// Temporary variable, used to store current query
		$templine = '';
		$successCount = 0;
		$errorCount = 0;

		// Read in entire file
		$lines = file($filename);
		foreach ($lines as $line) {
			// Skip it if it's a comment
			if (substr($line, 0, 2) == '--' || $line == '') {
				continue;
			}

			// Add this line to the current segment
			$templine .= $line;
			// If it has a semicolon at the end, it's the end of the query
			if (substr(trim($line), -1, 1) == ';') {
				// Perform the query
				$result = $adb->query($templine);
				if($result) {
					// Query performed sucessfully
					$successCount++;
				} else {
					// Error while performing query
					$errorCount++;
					//echo "Error performing query <b>$templine : ". mysql_error() . "</b>\n<br />";
				}

				// Reset temp variable to empty
				$templine = '';
			}
		}

		echo "SQL data imported successfully ($successCount suceess, $errorCount errors)\n<br />";
	}

	/**
	  * Set initial config after config table has been created
	  */
	function initConfig($adb) {
	    // Adding config parameters
        $config = array(
            'version' => 'vtiger600lite',
            'limit' => '20',
            'dateformat' => 'Y-M-d',
            'builderPublicAccess' => 'false',
            'showNullValues' => 'false',
            'apiEndpoint' => 'http://api.dev.itsapiens.eu/',
            'key' => ''
        );

        // Try to add key file in config if exists
        $keyFile = 'modules/AdvancedReports/key.php';
        if(file_exists($keyFile)) {
            $key = file_get_contents($keyFile);
            $config["key"] = $key;
        }

        // Insert config values
        foreach ($config as $key => $value) {
            $result = $adb->query("SELECT COUNT(*) AS count FROM `vtiger_advancedreports_config` WHERE `key` = '".$key."' LIMIT 1");
            $found = $adb->query_result($result, 0, "count");
            if($found < 1) {
                $adb->query("INSERT INTO `vtiger_advancedreports_config` (`key`, `value`) VALUES ('".$key."', '".$value."')");
            }
        }
	}
    //Perform cleanup operations
    function cleanup(){
        $keyFile = 'modules/AdvancedReports/key.php';
        if(file_exists($keyFile)) {
            if($this->suhosin_function_exists("chmod")){
                @chmod($keyFile, 0777);
            }
            // Try to delete key file
            if($this->suhosin_function_exists("unlink")){
                @unlink($keyFile);
            }

        }
    }

    function suhosin_function_exists($func) {
        if (extension_loaded('suhosin')) {
            $suhosin = @ini_get("suhosin.executor.func.blacklist");
            if (empty($suhosin) == false) {
                $suhosin = explode(',', $suhosin);
                $suhosin = array_map('trim', $suhosin);
                $suhosin = array_map('strtolower', $suhosin);
                return (function_exists($func) == true && array_search($func, $suhosin) === false);
            }
        }
        return function_exists($func);
    }

}