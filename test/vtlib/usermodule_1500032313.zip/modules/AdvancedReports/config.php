<?php
/**
 *
 * AnalyticReporting config file
 *
 */

return array(
	// Current module version (do not change, it will not add more functionality!)
	'version' => 'vtiger600lite',

	// Limitation of records per page
	'limit' => 20,

);