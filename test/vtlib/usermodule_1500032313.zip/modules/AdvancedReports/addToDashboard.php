<?php
/**
 * #4023
 * Add Advanced Report chart to dashboard as widget
 */

$adb = PearDatabase::getInstance();

$record			= vtlib_purify($_REQUEST['record']);
$title			= vtlib_purify($_REQUEST['title']);


global $current_user;
$userId = $current_user->id;
$linkId = null;
$r = $adb->query("SELECT linkid FROM vtiger_links WHERE linktype = 'DASHBOARDWIDGET' AND tabid=3 AND linkurl LIKE '%module=AdvancedReports%' LIMIT 1");
if($r){
    $r = $r->GetAll();
    $linkId = $r[0]['linkid'];
}
if($linkId && $record && $userId){
    $adb->pquery("INSERT INTO vtiger_module_dashboard_widgets(`linkid`,`userid`,`title`,`data`) VALUES(?,?,?,?)",array($linkId,$userId,$title,$record));
}