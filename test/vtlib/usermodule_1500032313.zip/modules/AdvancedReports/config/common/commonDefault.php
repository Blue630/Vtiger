<?php
$moduleName = "AdvancedReports";

return  array(
    'moduleName' => $moduleName,
    'url' => array(
        'index' => "index.php?module={$moduleName}&view=index",
        'reportBuilder' => "index.php?module={$moduleName}&view=ReportBuilder",
        'settings' => "index.php?module={$moduleName}&view=Settings",
        'settingsAjax' => "index.php?module={$moduleName}&view={$moduleName}Ajax&file=settings",
    ),
    'showNullValues' => true,
);