<?php
return array(
    'Leads' => array(
        0 => array(
            'tableName' => 'vtiger_leadacctrel',
            'applicableModules' => array(0 => 'Accounts'),
            'relModule' => false,
            'columns' => array(
                0 => array(
                    'name' => 'leadid',
                    'title' => 'leadid'
                ),
                1 => array(
                    'name' => 'accountid',
                    'title' => 'accountid'
                ),
            )
        )
    ),
    'all' => array(
        0 => array(
            'tableName' => 'vtiger_crmentityrel',
            'applicableModules' => array(0 => 'all'),
            'relModule' => true,
            'columns' => array(
                0 => array(
                    'name' => 'crmid',
                    'title' => 'crmid'
                ),
                1 => array(
                    'name' => 'relcrmid',
                    'title' => 'relcrmid'
                ),
                2 => array(
                    'name' => 'relmodule',
                    'title' => 'relmodule'
                ),
            ),
        )
    )
);