<?php
global $mod_strings;
return  array(
    'internal' => array(
        'postUrl' => 'index.php?module=AdvancedReports&view=AdvancedReportsAjax&file=reportBuilder',
        'reportUrl' => 'index.php?module=AdvancedReports&view=Report&record='
    ),
    'reportTypes' => array(
        0 => array(
            'name' => 'standard',
            'title' => $mod_strings['standard']
        ),
        1 => array(
            'name' => 'combined',
            'title' => $mod_strings['Combined']
        )
    ),
    'relationTypes' => array(
        0 => array(
            'name' => 'oneToMany',
            'title' => $mod_strings['oneToMany']
        ),
        1 => array(
            'name' => 'manyToMany',
            'title' => $mod_strings['manyToMany']
        )
    )
);