<?php

return array(
    'Documents'=>array(
        0 => array(
            'tableName' => "vtiger_attachmentsfolder",
            'parentModuleIdColumn' => 'folderid',
            'mainTableId' => 'folderid',
            'view' => false,
            'viewSql' => "",
            'viewParameters' => array(),
            'panelData' =>  array(
                'id' => '-5',
                'label' => 'Folders',
                'fields' => array(
                    0 => array(
                        'tablename'     => 'vtiger_attachmentsfolder',
                        'columnname'    => 'foldername',
                        'fieldname'     => 'foldername',
                        'fieldlabel'    => 'Folder name',
                        'uitype'        => '1',
                        'typeofdata'    => 'V~O',
                        'block'         => '-5'
                    ),
                    1 => array(
                        'tablename'     => 'vtiger_attachmentsfolder',
                        'columnname'    => 'description',
                        'fieldname'     => 'description',
                        'fieldlabel'    => 'Description',
                        'uitype'        => '1',
                        'typeofdata'    => 'V~O',
                        'block'         => '-5'
                    ),
                    2 => array(
                        'tablename'     => 'vtiger_attachmentsfolder',
                        'columnname'    => 'sequence',
                        'fieldname'     => 'sequence',
                        'fieldlabel'    => 'Sequence',
                        'uitype'        => '71',
                        'typeofdata'    => 'N~O',
                        'block'         => '-5'
                    ),
                )
            )
        )
    )
);