<?php
class CustomTables{
    private static $moduleDescriptor;
    public static function setModuleDescriptor($moduleDescriptor){
        CustomTables::$moduleDescriptor = $moduleDescriptor;
    }
    public static function getPanelLabel($moduleName, $blockNumber, $default=""){
        $moduleDescriptor = CustomTables::descriptorExists($moduleName);
        if(!$moduleDescriptor) return $default;

        foreach ($moduleDescriptor as $tableDescriptor) {
            if($tableDescriptor['panelData']['id'] == $blockNumber){
                return $tableDescriptor['panelData']['label'];
            }
        }

        return $default;
    }

    public static function injectFields($moduleName, $fieldData){
        $moduleDescriptor = CustomTables::descriptorExists($moduleName);
        if(!$moduleDescriptor) return $fieldData;

        foreach ($moduleDescriptor as $tableDescriptor) {
            $fieldData = array_merge($fieldData, $tableDescriptor['panelData']['fields']);
        }
        return $fieldData;
    }

    public static function injectTables($moduleName, $tables, dbConnector $dbConnector){
        $moduleDescriptor = CustomTables::descriptorExists($moduleName);
        if(!$moduleDescriptor) return $tables;

        foreach ($moduleDescriptor as $tableDescriptor) {
            $tableName = $tableDescriptor['tableName'];
            $idColumn = $tableDescriptor['parentModuleIdColumn'];
            if($tableDescriptor['view']){
                $viewSql = $tableDescriptor['viewSql'];
                $viewParameters = $tableDescriptor['viewParameters'];
                $dbConnector->createView($viewSql, $viewParameters, $tableName);
            }
            $tables[] = array('name' => $tableName, 'idCol' => $idColumn);

        }
        return $tables;

    }
    public static function injectMainTableId($moduleName, $childTableName){
        $moduleDescriptor = CustomTables::descriptorExists($moduleName);
        if(!$moduleDescriptor) return null;
        $mainTableId = null;

        foreach ($moduleDescriptor as $tableDescriptor) {
            if($tableDescriptor['tableName'] != $childTableName) continue;
            $mainTableId = isset($tableDescriptor['mainTableId'])?$tableDescriptor['mainTableId'] : null;
        }

        return $mainTableId;
    }
    private static function descriptorExists($moduleName){
        if(!isset(CustomTables::$moduleDescriptor[$moduleName])){
            return false;
        }
        return CustomTables::$moduleDescriptor[$moduleName];
    }

}