<?php
/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(
    
);

$jsLanguageStrings = array(
    "LBL_DEACTIVATE_QUESTION" => "Deseja realmente desativar sua chave da licença?",
);