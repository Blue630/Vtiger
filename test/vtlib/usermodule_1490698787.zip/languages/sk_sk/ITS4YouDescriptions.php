<?php
/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
$languageStrings = array(
    'ITS4YouDescriptions' => 'Descriptions 4 You',
    'SINGLE_ITS4YouDescriptions' => 'Popis',
    'LBL_ADD_RECORD' => 'Pridať popis',
    'LBL_RECORDS_LIST' => 'Zoznam popisov',
    'LBL_ITS4YOUDESCRIPTIONS_INFORMATION' => 'Detail popisu',
    'Description No' => 'Číslo popisu',
    'Description Name' => 'Názov Popisu',
    'Description' => 'Popis',
    'LBL_ALLOWED_MODULES' => 'Integrácia',
    'LBL_AVAILABLE_MODULES' => 'Dostupné moduly',
    'Choose_field' => 'Vyberte pole',

    // license
    "LBL_INSTALL" => "inštalácia",
    "LBL_EXPRESS" => "Expres",
    "LBL_CUSTOM" => "Vlastný",
    "LBL_EXPRESS_DESC" => "Je vyžadovaná štandardná inštalácia vtiger.",
    "LBL_FINISH" => "Koniec",
    "LBL_NEXT" => "Ďalej",
    "LBL_FILE" => "súbor",
    "LBL_INSTAL_ERROR" => "Počas inštalácie Descriptions 4 You došlo k chybe.",
    "LBL_ERROR_TBL" => "Nasledujúce úlohy sa nepodarilo dokončiť",
    "LBL_RELOAD" => "Skúsiť znova",
    "LBL_INSERT_KEY" => "Prosím zadajte licenčný kľúč, ktorý ste dostali v emaile s potvrdením objednávky.",
    "LBL_VALIDATE" => "Overiť",
    "LBL_INVALID_KEY" => "Nesprávny licenčný kľúč! Kontaktujte prosím predajcu Descriptions 4 You.",
    "LBL_ONLINE_ASSURE" => "Prosím skontrolujte či váš počítač má pripojenie k internetu, aby sa mohlo uskutočniť overenie.",
    "LBL_ORDER_NOW" => "Objednajte si teraz",
    "LBL_DOWNLOAD" => "Na stiahnutie",
    "LBL_VALIDATION" => "Overenie",
    "LBL_CUSTOMIZATION" => "Prispôsobenie",
    "LBL_WELCOME" => "Vitajte v sprievodcovi inštaláciou Descriptions 4 You",
    "LBL_WELCOME_DESC" => "Týmto nainštalujete Descriptions 4 You do vášho vtiger CRM.",
    "LBL_WELCOME_FINISH" => "Je potrebné dokončiť inštaláciu bez akéhokoľvek prerušenia.",
    "LBL_TRY_AGAIN" => "Skúsiť znova",
    "LBL_FINAL_INSTRUCTIONS_TITLE" => "Váš licenčný kľúč bol úspešne overený.",
    "LBL_FINAL_INSTRUCTIONS" => "Kliknite na tlačidlo \"Dokončiť \" a budete presmerovaný na <b> Descriptions 4 You ListView </ b>.",
    'LICENSE_SETTINGS' => 'Licenčné nastavenia',
    'LICENSE_SETTINGS_INFO' => 'Správa všetkých nastavení Descriptions 4 You licencie.',
    'LBL_LICENCEKEY' => 'Licenčný kľúč',
    'LBL_ACTIVATE_KEY' => 'Aktivuj licenciu',
    'LBL_ACTIVATE_KEY_TITLE' => 'Nastaviť licenčný kľúč na aktívny',
    "LBL_INVALID_FOPEN_CURL" => "Povoliť <strong> allow_url_fopen </ strong> nastavenia alebo <strong> cURL </ strong> rozšírenie v nastavení PHP.",
    "LBL_REACTIVATE" => "Reaktivácia licencie",
    "LBL_REACTIVATE_DESC" => "V prípade, že sa vyskytne problém s licenčným kľúčom.",
    "REACTIVATE_SUCCESS" => "Úspešne ste reaktivovali váš Descriptions 4 You.",
    "REACTIVATE_ERROR" => "Došlo k chybe pri (re)aktivácii licenčného kľúča.",
    "LBL_DEACTIVATE" => "Deaktivovať licenciu",
    "LBL_DEACTIVATE_TITLE" => "Deaktivovať licenciu",
    "LBL_DEACTIVATE_QUESTION" => "Naozaj chcete deaktivovať Váš licenčný kľúč?",
    "LBL_DEACTIVATE_DESC" => "After deactivation You will be allowed only to export Descriptions 4 You templates.<br /> After reactivation You will get the standard functionality.",
    "LBL_DEACTIVATE_ERROR" => "Deaktivácia licenčného kľúča zlyhala.",
    "LBL_ACTIVATE_SUCCESS" => "Úspešne ste aktivovali Vaše Descriptions 4 You.",
    "LBL_DEACTIVATE_SUCCESS" => "Licenčný kľúč bol úspešne deaktivovaný.",
    "LBL_UNINSTALL" => "Odinštalovať Descriptions 4 You",
    "LBL_UNINSTALL_DESC" => "Odinštalovať Descriptions 4 You kompletne z vtiger.",
    "LBL_UNINSTALL_CONFIRM" => "Naozaj chcete úplne odinštalovať Descriptions 4 You a deaktivovať licenciu?",
    "LBL_TERMS_INFORMATION" => "Obchodné podmienky",
    "Terms and Conditions" => "Obchodné podmienky",
    'LBL_EXPORT_TO_PDF' => 'Export do PDF',
    'LBL_SEND_MAIL_PDF' => 'Poslať e-mail s PDF',

    // integration
    "LBL_INTEGRATION" => "Integrácia",
    "LBL_INTEGRATION_DESC" => "Integrácia Descriptions 4 You do iných modulov",
    "INTEGRATION" => "Integrácia",
    
    //copyright
    "COPYRIGHT" => ":: IT-Solutions4You",
    
    //installation
    "LBL_LICENSE_KEY" => "Licenčný kľúč",
    "LBL_INSTALL_SUCCESS" => "Descriptions 4 You bol úspešne nainštalovaný.",
    "LBL_LICENSE" => "Licenčné nastavenia",
    "LBL_LICENSE_DESC" => "Správa všetkých nastavení Descriptions 4 You licencie.",
    "REACTIVATE_SUCCESS" => "Úspešne ste reaktivovali váš Descriptions 4 You.",
    "LBL_INACTIVE" => "Descriptions 4 You je neaktivovaný. Prosím zadajte licenčný kľúč.",
    "ALERT_DOC_TITLE" => "Názov dokumentu nemôže byť prázdny.",
    
    //installation
    "LBL_LICENSE_KEY" => "Licenčný kľúč",
    "LBL_INSTALL_SUCCESS" => "Descriptions 4 You bol úspešne nainštalovaný.",
    "LBL_LICENSE" => "Licenčné nastavenia",
    "LBL_LICENSE_DESC" => "Správa všetkých nastavení Descriptions 4 You licencie.",
    "REACTIVATE_SUCCESS" => "Úspešne ste reaktivovali váš Descriptions 4 You.",
    "LBL_INACTIVE" => "Descriptions 4 You je neaktivovaný. Prosím zadajte licenčný kľúč.",
    "ALERT_DOC_TITLE" => "Názov dokumentu nemôže byť prázdny.",
    
    //uninstal
    "LBL_UNINSTALL" => "Odinštalovať",
    "LBL_UNINSTALL_DESC" => "Odstrániť Descriptions 4 You kompletne z vtiger.",
    
    // v. 600.01.01
	 'Global' => 'Globálny popis',
    'TaC' => 'Globálne Všeobcné obchodné podmienky',
    
    "Cashflow4You" => "Pokladňa",
    "CreditNotes4You" => "Dobropis",
    "ITS4YouDeliveryNotes" => "Dodací list",
    "ITS4YouPreInvoice" => "Zálohové faktúry",
);

$jsLanguageStrings = array(
    "LBL_DEACTIVATE_QUESTION" => "Určite chcete deaktivovať Váš licenčný kľúč?",
    "LBL_UNINSTALL_CONFIRM" => "Naozaj chcete úplne odstrániť Descriptions 4 You z vášho vtiger a deaktivovať svoje Descriptions 4 You licenciu?",
);
