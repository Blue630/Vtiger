/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

if (jQuery("#EditView").length > 0) {
    module = jQuery("#EditView").find('input[name="module"]').val();
    if (module != 'ITS4YouDescriptions' && module != 'Documents') {
        jQuery.ajax('index.php?module=ITS4YouDescriptions&action=GetFieldsForModule&for_module=' + module).done(function (data) {
            var textareas = data.split(',,');
            var qqqhd = jQuery('textarea');
            for (var i = 0; i < qqqhd.length; i++) {
                for (var j = 0; j < textareas.length - 1; j++) {
                    if (textareas[j] === qqqhd[i].name) {
                        var divelem = document.createElement('div');
                        divelem.id = 'div_desc_' + textareas[j];
                        jQuery.ajax('index.php?module=ITS4YouDescriptions&view=GetControllsForField&formodule=' + jQuery("#EditView").find('input[name="module"]').val() + '&field=' + textareas[j]).done(function (data) {
                            var splitted = data.split('|#@#|');
                            jQuery('#div_desc_' + splitted[0]).html(splitted[1]);
                        })
                        jQuery("#EditView").find('textarea[name="' + textareas[j] + '"]').before(divelem);
                    }
                }
            }
        });
        /*jQuery.ajax('index.php?module=ITS4YouDescriptions&view=SidebarWidget&record=' + jQuery("#EditView").find('input[name="record"]').val() + '&source_module=' + jQuery("#EditView").find('input[name="module"]').val()).done(function (data) {
         jQuery(".sideBarContents").after(data);
         });*/

        if (typeof (ITS4YouDescriptions_Editing_Js) == 'undefined') {
            var ITS4YouDescriptions_Editing_Js = {
                initialize: function () {
                },
                showModalEditWindow: function (affected_textarea) {
                    var aDeferred = jQuery.Deferred();
                    var progressIndicatorElement = jQuery.progressIndicator({
                        'position': 'html',
                        'blockInfo': {
                            'enabled': true
                        }
                    });
                    var url = 'index.php?module=ITS4YouDescriptions&view=ModalEditWindow&affected_textarea=' + affected_textarea + '&formodule=' + jQuery("#EditView").find('input[name="module"]').val() + '&affected_textarea_value=' + jQuery("#EditView").find('textarea[name="' + affected_textarea + '"]').text();
                    AppConnector.request(url).then(
                            function (data) {
                                var callBackFunction = function (data) {
                                }

                                progressIndicatorElement.progressIndicator({'mode': 'hide'});
                                app.showModalWindow(data, function (data) {
                                    if (typeof callBackFunction == 'function') {
                                        callBackFunction(data);
                                    }
                                }, {'width': '780px'});
                            },
                            function (error) {
                                aDeferred.reject(error);
                            }
                    );
                    return aDeferred.promise();

                },
                replaceInTextarea: function (affected_textarea, formodule) {
                    var thisInstance = this;
                    thisInstance.requestForTextarea(affected_textarea, formodule, 'replace');
                    return;
                },
                addToTextarea: function (affected_textarea, formodule) {
                    var thisInstance = this;
                    thisInstance.requestForTextarea(affected_textarea, formodule, 'add');
                    return;
                },
                requestForTextarea: function (affected_textarea, formodule, type) {
                    var aDeferred = jQuery.Deferred();
                    var progressIndicatorElement = jQuery.progressIndicator({
                        'position': 'html',
                        'blockInfo': {
                            'enabled': true
                        }
                    });
                    var url = 'index.php?module=ITS4YouDescriptions&action=GetDescriptionContent&affected_textarea=' + affected_textarea + '&formodule=' + formodule + '&descriptionid=' + jQuery("#sel_desc4you_" + affected_textarea).val();
                    AppConnector.request(url).then(
                            function (data) {
                                aDeferred.resolve(data);
                                var textareaelem = jQuery("#EditView").find('textarea[name="' + affected_textarea + '"]');
                                if (type === 'replace') {
                                    textareaelem.html(data.result);
                                } else if (type === 'add') {
                                    textareaelem.html(textareaelem.html() + data.result);
                                }
                                progressIndicatorElement.progressIndicator({'mode': 'hide'});
                            }
                    );
                    return aDeferred.promise();
                }
            }
        }
    }

} else if (jQuery("#detailView").length > 0 || app.getViewName() === 'Detail') {
	jQuery.ajax('index.php?module=ITS4YouDescriptions&action=GetFieldsForModule&for_module=' + jQuery('#module').val()).done(function (data) {
        var textareas = data.split(',,');
        for (var j = 0; j < textareas.length - 1; j++) {
            module = jQuery('#module').val();
            if (module != 'ITS4YouDescriptions' && module != 'Documents') {
                td_fieldname = module + '_detailView_fieldValue_' + textareas[j];
                span_text = jQuery('#' + td_fieldname + ' span:first-child').text();
                jQuery('#' + td_fieldname + ' span:first-child').html(span_text);
            }
        }
    });

}
