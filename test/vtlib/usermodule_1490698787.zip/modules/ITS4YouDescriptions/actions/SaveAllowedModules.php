<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_SaveAllowedModules_Action extends Vtiger_Action_Controller {

    public function checkPermission(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $record = $request->get('record');

        if (!Users_Privileges_Model::isPermitted($moduleName, 'Save', $record)) {
            throw new AppException('LBL_PERMISSION_DENIED');
        }
    }

    public function process(Vtiger_Request $request) {
        $AllowedModules = ITS4YouDescriptions_AllowedModules_Model::getAllowedModules();
        $AddModules = Array();
        $RemoveModules = $AllowedModules;
        foreach ($request->getAll() as $key => $value) {
            if (substr($key, 0, 8) == 'allowed_') {
                $tabid = substr($key, 8);
                if (!isset($AllowedModules[$tabid])) {
                    $AddModules[] = $tabid;
                }
                unset($RemoveModules[$tabid]);
            }
        }
        foreach ($AddModules as $tabid) {
            $this->addModule($request, $tabid);
        }
        foreach ($RemoveModules as $tabid => $throw) {
            $this->removeModule($request, $tabid);
        }
        header("Location: index.php?module=" . $request->get('module') . '&view=AllowedModules');
    }

    private function addModule(Vtiger_Request $request, $tabid) {
        $newValue = getTabModuleName($tabid);
        $moduleName = $request->get('module');
        $pickListName = 'desc4youmodule';
        $moduleModel = Settings_Picklist_Module_Model::getInstance($moduleName);
        $fieldModel = Settings_Picklist_Field_Model::getInstance($pickListName, $moduleModel);
        $rolesSelected = array();
        if ($fieldModel->isRoleBased()) {
            $userSelectedRoles = $request->get('rolesSelected', array());
            if (in_array('all', $userSelectedRoles)) {
                $roleRecordList = Settings_Roles_Record_Model::getAll();
                foreach ($roleRecordList as $roleRecord) {
                    $rolesSelected[] = $roleRecord->getId();
                }
            } else {
                $rolesSelected = $userSelectedRoles;
            }
        }
        $id = $moduleModel->addPickListValues($fieldModel, $newValue, $rolesSelected);
        $LinksModel = new ITS4YouDescriptions_Links_Model();
        $LinksModel->addLinksForModule($newValue);
    }

    private function removeModule(Vtiger_Request $request, $tabid) {
        $moduleName = $request->get('module');
        $pickListName = 'desc4youmodule';
        $valueToDelete = getTabModuleName($tabid);
        $moduleModel = Settings_Picklist_Module_Model::getInstance($moduleName);
        vimport('~~/vtigerversion.php');
        if(empty($vtiger_current_version)){
			$vtiger_current_version = $_SESSION['vtiger_version'];
		}
        if($vtiger_current_version=='6.0.0'){
        	$moduleModel->remove($pickListName, $valueToDelete, 'Global', $moduleName);
		} else {
			$adb = PEARDatabase::getInstance();
			$sql = "SELECT desc4youmoduleid FROM vtiger_desc4youmodule WHERE desc4youmodule=?";
			$res = $adb->pquery($sql, array($valueToDelete));
			if($adb->num_rows($res) > 0){
				$row = $adb->fetchByAssoc($res);
				$valueToDeletedId = $row['desc4youmoduleid'];
				$res1 = $adb->pquery($sql, array('Global'));
				if($adb->num_rows($res1)>0){
					$row1 = $adb->fetchByAssoc($res1);
					$globalId = $row1['desc4youmoduleid'];
					$moduleModel->remove($pickListName, $valueToDeletedId, $globalId, $moduleName);
				}
			}
		}
        $LinksModel = new ITS4YouDescriptions_Links_Model();
        $LinksModel->removeLinksForModule($valueToDelete);
    }

}
