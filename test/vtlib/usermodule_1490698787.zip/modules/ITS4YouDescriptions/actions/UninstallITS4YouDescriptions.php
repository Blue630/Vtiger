<?php
/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_UninstallITS4YouDescriptions_Action extends Settings_Vtiger_Basic_Action {

    function __construct() {
        parent::__construct();
    }

    function process(Vtiger_Request $request) {
        $Vtiger_Utils_Log = true;
        include_once('vtlib/Vtiger/Module.php');
        $adb = PearDatabase::getInstance();
        $module = Vtiger_Module::getInstance('ITS4YouDescriptions');
        if ($module) {
            $ITS4YouDescriptions = new ITS4YouDescriptions_Module_Model();
            
            $request->set('key', $ITS4YouDescriptions->GetLicenseKey());
            
            $ITS4YouDescriptions_License_Action_Model = new ITS4YouDescriptions_License_Action();
            $ITS4YouDescriptions_License_Action_Model->deactivateLicense($request);

            $module->delete();
            @shell_exec('rm -r modules/ITS4YouDescriptions');
            @shell_exec('rm -r layouts/vlayout/modules/ITS4YouDescriptions');
            @shell_exec('rm -f languages/ar_ae/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/ar_ae/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/cz_cz/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/cz_cz/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/de_de/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/de_de/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/en_gb/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/en_gb/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/en_us/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/en_us/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/es_es/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/es_es/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/es_mx/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/es_mx/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/fr_fr/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/fr_fr/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/hi_hi/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/hi_hi/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/hu_hu/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/hu_hu/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/it_it/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/it_it/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/nl_nl/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/nl_nl/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/pl_pl/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/pl_pl/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/pt_br/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/pt_br/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/ro_ro/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/ro_ro/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/ru_ru/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/ru_ru/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/sk_sk/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/sk_sk/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/sv_se/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/sv_se/Settings/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/tr_tr/ITS4YouDescriptions.php');
            @shell_exec('rm -f languages/tr_tr/Settings/ITS4YouDescriptions.php');

            $adb->query("DROP TABLE IF EXISTS its4you_descriptions");
            $adb->query("DROP TABLE IF EXISTS its4you_descriptionscf");
            $adb->query("DROP TABLE IF EXISTS its4you_descriptions_settings");
            $adb->query("DROP TABLE IF EXISTS its4you_descriptions_license");
            $adb->query("DROP TABLE IF EXISTS its4you_descriptions_version");
            $adb->query("DROP TABLE IF EXISTS its4you_descriptions");
            $adb->query("DROP TABLE IF EXISTS vtiger_desc4youmodule");
            $adb->query("DROP TABLE IF EXISTS vtiger_desc4youmodule_seq");
            

            $result = array('success' => true);
        } else {
            $result = array('success' => false);
        }
        ob_clean();
        $response = new Vtiger_Response();
        $response->setResult($result);
        $response->emit();
    }
}
