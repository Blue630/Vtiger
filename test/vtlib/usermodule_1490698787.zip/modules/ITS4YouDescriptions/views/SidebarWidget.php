<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_SidebarWidget_View extends Vtiger_BasicAjax_View {

    function process(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);
        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $this->viewName = $request->get('viewname');

        $viewer->assign('TEMPLATES', ITS4YouDescriptions_Record_Model::getTemplatesForModule($request->get('source_module')));
        $Textareas = ITS4YouDescriptions_Record_Model::getTextareasForModule($request->get('source_module'));
        $viewer->assign('TEXTAREAS', $Textareas);
        $viewer->assign('TEXTAREAS_COUNT', count($Textareas));

        $viewer->assign('VIEW', $request->get('view'));
        $viewer->assign('MODULE_MODEL', $moduleModel);
        $viewer->assign('CURRENT_USER_MODEL', Users_Record_Model::getCurrentUserModel());
        $viewer->assign('CURRENT_MODULE', $request->get('module'));
        $viewer->assign('SOURCE_MODULE', $request->get('source_module'));
        $viewer->view('SidebarWidget.tpl', $moduleName);
    }

}
