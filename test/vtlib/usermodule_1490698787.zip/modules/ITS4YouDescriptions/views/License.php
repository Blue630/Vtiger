<?php
/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_License_View extends Vtiger_Index_View {

    
    public function preProcess(Vtiger_Request $request, $display = true) {
        $ITS4YouDescriptions = new ITS4YouDescriptions_Module_Model();
        $viewer = $this->getViewer($request);
        $moduleName = $request->getModule();
        $viewer->assign('QUALIFIED_MODULE', $moduleName);
        Vtiger_Basic_View::preProcess($request, false);
        $viewer = $this->getViewer($request);

        $moduleName = $request->getModule();
        
        $linkParams = array('MODULE' => $moduleName, 'ACTION' => $request->get('view'));
       
        $linkModels = $ITS4YouDescriptions->getSideBarLinks($linkParams);
        $viewer->assign('QUICK_LINKS', $linkModels);
        
        $viewer->assign('CURRENT_USER_MODEL', Users_Record_Model::getCurrentUserModel());
        $viewer->assign('CURRENT_VIEW', $request->get('view'));
        
        if ($display) {
            $this->preProcessDisplay($request);
        }
    }
    
    public function process(Vtiger_Request $request) {
        $ITS4YouDescriptions = new ITS4YouDescriptions_Module_Model();

        $viewer = $this->getViewer($request);

        $mode = $request->get('mode');
        
        $viewer->assign("VERSION", ITS4YouDescriptions_Version_Helper::getVersion());
        $viewer->assign("MODE", $mode);             
        
        $viewer->assign("LICENSE", $ITS4YouDescriptions->GetLicenseKey());
        $viewer->assign("VERSION_TYPE", $ITS4YouDescriptions->GetVersionType());            
        
        $viewer->view('License.tpl', 'ITS4YouDescriptions');         
    }
    
    function getHeaderScripts(Vtiger_Request $request) {
            $headerScriptInstances = parent::getHeaderScripts($request);
            $moduleName = $request->getModule();

            $jsFileNames = array(
                "layouts.vlayout.modules.ITS4YouDescriptions.resources.License",
            );
            $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
            $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
            return $headerScriptInstances;
        }
}     