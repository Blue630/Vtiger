<?php
/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_IndexAjax_View extends Vtiger_IndexAjax_View {

    function __construct() {
        parent::__construct();
        $this->exposeMethod('showSettingsList');
        $this->exposeMethod('editLicense');

    }
    
    function showSettingsList(Vtiger_Request $request) {

        $ITS4YouDescriptions = new ITS4YouDescriptions_Module_Model();

        $viewer = $this->getViewer($request);
        $moduleName = $request->getModule();

        $viewer->assign('MODULE', $moduleName);

        $linkParams = array('MODULE' => $moduleName, 'ACTION' => $request->get('view'), 'MODE' => $request->get('mode'));
        $linkModels = $ITS4YouDescriptions->getSideBarLinks($linkParams);
        
        $viewer->assign('QUICK_LINKS', $linkModels);

        $parent_view = $request->get('pview');
        
        if ($parent_view == "EditProductBlock") $parent_view = "ProductBlocks";
        
        $viewer->assign('CURRENT_PVIEW', $parent_view);
        
        echo $viewer->view('SettingsList.tpl', 'ITS4YouDescriptions', true);

    }
    
    function editLicense(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);

        $moduleName = $request->getModule();
       
        $type = $request->get('type');
        $viewer->assign("TYPE", $type);
        
        $key = $request->get('key');
        $viewer->assign("LICENSEKEY", $key);
        
        echo $viewer->view('EditLicense.tpl', 'ITS4YouDescriptions', true);
    }
}