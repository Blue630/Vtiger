<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_GetControllsForField_View extends Vtiger_BasicAjax_View {

    function process(Vtiger_Request $request) {
        $fieldname = $request->get('field');
        $moduleName = $request->getModule();
        $formodule = $request->get('formodule');
        echo $fieldname;
        echo '|#@#|';
        //print_r($_REQUEST);
        $Descriptions = ITS4YouDescriptions_Module_Model::getDescriptionsForModule($formodule, $fieldname);
        //print_r($Descriptions);
        $viewer = $this->getViewer($request);
        $viewer->assign('DESCRIPTIONS', $Descriptions);
        $viewer->assign('FIELDNAME', $fieldname);
        $viewer->assign('FORMODULE', $formodule);
        $viewer->view('GetControllsForField.tpl', $moduleName);
    }

}
