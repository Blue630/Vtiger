<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_Links_Model extends Vtiger_Link {

    private $used_in_modules = Array();
    
    public function addLinks() {
        $this->actualizeAllowedModules();
        foreach ($this->used_in_modules as $moduleName) {
            $this->addLinksForModule($moduleName);
        }
    }

    public function removeLinks() {
        $this->actualizeAllowedModules();
        $tabid = getTabId("ITS4YouDescriptions");
        Vtiger_Link::deleteAll($tabid);
        foreach ($this->used_in_modules as $moduleName) {
            $this->removeLinksForModule($moduleName);
        }
    }

    private function actualizeAllowedModules() {
        global $adb;
        $res = $adb->query("SELECT vtiger_tab.tabid, vtiger_tab.name FROM vtiger_links INNER JOIN vtiger_tab ON vtiger_tab.tabid=vtiger_links.tabid WHERE linklabel='ITS4YouDescriptionsWidget' ORDER BY tabid");
        while ($row = $adb->fetchByAssoc($res)) {
            if (!in_array($row['name'], $this->used_in_modules))
                $this->used_in_modules[] = $row['name'];
        }
    }

    public function addLinksForModule($moduleName) {
        require_once('vtlib/Vtiger/Module.php');
        /*$link_module = Vtiger_Module::getInstance($moduleName);
        $link_module->addLink('DETAILVIEWSIDEBARWIDGET', 'ITS4YouDescriptionsWidget', 'module=ITS4YouDescriptions&view=SidebarWidget&for_module=$MODULE$&record=$RECORD$');
        $link_module->addLink('HEADERSCRIPT', 'ITS4YouDescriptions_HeaderScript', 'layouts/vlayout/modules/ITS4YouDescriptions/resources/ITS4YouDescriptions.js');*/
    }

    public function removeLinksForModule($moduleName) {
        require_once('vtlib/Vtiger/Link.php');
        /*$tabid = getTabId($moduleName);
        Vtiger_Link::deleteLink($tabid, "DETAILVIEWSIDEBARWIDGET", "ITS4YouDescriptionsWidget");
        Vtiger_Link::deleteLink($tabid, "HEADERSCRIPT", "ITS4YouDescriptions_HeaderScript");*/
    }

    public function DeleteAllRefLinks() {
        require_once('vtlib/Vtiger/Link.php');
        /*$link_res = $this->db->query("SELECT tabid FROM vtiger_tab");
        while ($link_row = $this->db->fetchByAssoc($link_res)) {
            Vtiger_Link::deleteLink($link_row["tabid"], "DETAILVIEWSIDEBARWIDGET", "ITS4YouDescriptionsWidget");
            Vtiger_Link::deleteLink($link_row["tabid"], "HEADERSCRIPT", "ITS4YouDescriptions_HeaderScript");
        }*/
    }

}
