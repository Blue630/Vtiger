<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_Record_Model extends Vtiger_Record_Model {

    public function get($key) {
        $value = parent::get($key);
        if ($key === 'description') {
            return decode_html($value);
        }
        return $value;
    }

    public static function getTemplatesForModule($moduleName) {
        $Templates = Array();
        $db = PearDatabase::getInstance();
        $res = $db->pquery("SELECT descriptionid, descriptionname FROM its4you_descriptions INNER JOIN vtiger_crmentity ON crmid=descriptionid AND deleted=0 WHERE desc4youmodule IN ('Global', ?)", array($moduleName));
        $num_rows = $db->num_rows($res);
        while ($row = $db->fetchByAssoc($res)) {
            if ($num_rows == 1) {
                $row['is_default'] = 1;
            }
            $Templates[$row['descriptionid']] = $row;
        }
        return $Templates;
    }

    public static function getTextareasForModule($moduleName, $include_addresses = TRUE) {
        $Textareas = Array();
        $db = PearDatabase::getInstance();
        $AllowedModules = ITS4YouDescriptions_AllowedModules_Model::getAllowedModuleNames();
        if (in_array($moduleName, $AllowedModules)) {
            $sql = "SELECT fieldid, fieldlabel, fieldname "
                    . " FROM vtiger_field "
                    . " INNER JOIN vtiger_blocks ON blockid=block "
                    . " WHERE vtiger_field.tabid=? "
                    . " AND uitype IN (19, 20, 21) ";
            if (!$include_addresses) {
                $sql .= " AND fieldname NOT IN ('bill_street', 'ship_street', 'lane', 'mailingstreet', 'otherstreet', 'comment', 'street')";
            }
            $sql .= "ORDER BY vtiger_blocks.sequence, vtiger_field.sequence";
            $res = $db->pquery($sql, array(getTabId($moduleName)));
            $num_rows = $db->num_rows($res);
            while ($row = $db->fetchByAssoc($res)) {
                $row['fieldlabel'] = html_entity_decode($row['fieldlabel'], ENT_COMPAT, 'utf-8');
                if ($num_rows == 1) {
                    $row['is_default'] = 1;
                }
                /** TODO: check if the user has rights to access that field * */
                /** TODO: check if the user has rights to edit this record * */
                //Users_Privileges_Model::isPermitted($moduleName, 'EditView', $record)
                $Textareas[$row['fieldid']] = $row;
            }
        }
        return $Textareas;
    }

    public static function getTemplateDescription($templateid) {
        $return = '';
        $adb = PearDatabase::getInstance();
        $res = $adb->pquery("SELECT description FROM vtiger_crmentity WHERE crmid=? AND deleted=0", array($templateid));
        if ($adb->num_rows($res) === 1) {
            $row = $adb->fetchByAssoc($res);
            $return = $row['description'];
        }
        return $return;
    }

}
