<?php

/* * *******************************************************************************
 * The content of this file is subject to the Descriptions 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */
error_reporting(0);
class ITS4YouDescriptions_AllowedModules_Model extends Vtiger_Module_Model {

    /**
     * Function to get focus of this object
     * @return <type>
     */
    public function getFocus() {
        if (!$this->focus) {
            $this->focus = CRMEntity::getInstance($this->getName());
        }
        return $this->focus;
    }

    /**
     * Function to get Instance of this module
     * @param <String> $moduleName
     * @return <Settings_Vtiger_CustomRecordNumberingModule_Model> $moduleModel
     */
    public static function getInstance($moduleName, $tabId = false) {
        $moduleModel = new self();
        $moduleModel->name = $moduleName;
        if ($tabId) {
            $moduleModel->id = $tabId;
        }
        return $moduleModel;
    }

    /**
     * Function to ger Supported modules for Descriptions4You
     * @return <Array> list of supported modules <Vtiger_Module_Model>
     */
    public static function getSupportedModules() {
        $db = PearDatabase::getInstance();
        $modulesModels = Array();
        $sql = "SELECT tabid, name, desc4youmoduleid FROM vtiger_tab LEFT JOIN vtiger_desc4youmodule ON name=desc4youmodule WHERE isentitytype = 1 AND vtiger_tab.presence = 0 AND tabid IN (SELECT DISTINCT tabid FROM vtiger_field WHERE uitype = 4 AND tablename!='its4you_descriptions')";
        $result = $db->pquery($sql, array());
        while ($row = $db->fetchByAssoc($result)) {
            $modulesModels[$row['tabid']] = $row;
        }
        return $modulesModels;
    }

    /**
     * Function to ger Supported modules for Descriptions4You
     * @return <Array> list of supported modules <Vtiger_Module_Model>
     */
    public static function getAllowedModules() {
        $modulesModels = Array();
        /*$db = PearDatabase::getInstance();
        $sql = "SELECT tabid, name FROM vtiger_desc4youmodule INNER JOIN vtiger_tab ON name=desc4youmodule WHERE isentitytype = 1 AND vtiger_tab.presence = 0";
        $result = $db->pquery($sql, array());
        while($row = $db->fetchByAssoc($result)){
            $moduleModels[$row['tabid']] = ITS4YouDescriptions_AllowedModules_Model::getInstance($row['name'], $row['tabid']);
        }*/
        $ModuleNames = self::getAllowedModuleNames();
        foreach($ModuleNames as $tabid => $tabname){
            $moduleModels[$tabid] = ITS4YouDescriptions_AllowedModules_Model::getInstance($tabname, $tabid);
        }
        return $moduleModels;
    }

    /**
     * Function to ger Supported module names for Descriptions4You
     * @return <Array> list of supported modules 
     */
    public static function getAllowedModuleNames() {
        $db = PearDatabase::getInstance();
        $modulesModels = Array();
        $sql = "SELECT tabid, name FROM vtiger_desc4youmodule INNER JOIN vtiger_tab ON name=desc4youmodule WHERE isentitytype = 1 AND vtiger_tab.presence = 0";
        $result = $db->pquery($sql, array());
        while($row = $db->fetchByAssoc($result)){
            $moduleModels[$row['tabid']] = $row['name'];
        }
        return $moduleModels;
    }

}
