
<?php
/**************************************************************************************
 *	Copyright (C) 2019  Simone Macrì e modificato da Giorgio Papallo
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : FatturaElettronica
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1, 7.1.0
 *  Author              : Simone Macrì - web: www.antworks.it - email: simone.macri@antworks.it
 *  Author							: Giorgio Papallo - web: www.papallo.it - email: giorgio@papallo.it
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

function getConfig() {
	include "modules/FatturaElettronica/resources/config.inc.php";
	return $config;
}


function retriveEntity($id, $module) {
	try {
		$focus = CRMEntity::getInstance($module);
		$focus->id = $id;
		$focus->apply_field_security();
		$focus->retrieve_entity_info($id,$module);
		return $focus;
	} catch(Exception $e) {
		echo $e->getMessage();
		return "";
	}
}

function dumpEntity($entity) {
	try {
		foreach ($entity->column_fields as $fieldname => $value)
			echo "$fieldname => $value</BR>";
	} catch(Exception $e) {
		echo $e->getMessage();
	}
}

function retriveInvoice($id) {
	try {
		$invoice = retriveEntity($id, "Invoice");
		$accountid=$invoice->column_fields["account_id"];
		$account = retriveEntity($accountid, "Accounts");
		$contactid=$invoice->column_fields["contact_id"];
		$contact = retriveEntity($contactid, "Contacts");
		$related_products = getAssociatedProducts("Invoice",$invoice);

		$ret = [
			"invoice" => $invoice,
			"account" => $account,
			"contact" => $contact,
			"products" => $related_products
		];

		return $ret;
	} catch (WebServiceException $ex) {
		echo $ex->getMessage();
	}
}

function get_columnname($label) {
	try {
		$adb = PearDatabase::getInstance();
		$query = "select columnname from vtiger_field where fieldlabel = \"".$label."\" and tablename like \"vtiger_account%\"";
		$ids = $adb->pquery($query);
		if ($adb->num_rows($ids) > 0) {
			$data = $adb->fetch_array($ids);
			return $data['columnname'];
		} else
			return null;
	} catch(Exception $e) {
		echo $ex->getMessage();
	}
}

function saveDocument($id, $type) {
    try {
        $config = getConfig();
        $debug = $config['debug'];
        $debugLocation = $config['debugLocation'];

        $invoice = retriveInvoice($id);
        #$xml = serializzaDocumento($invoice, $type);
        $xml = genera_xml_fattura($invoice, $type);
        file_put_contents("FATTURA", $xml);

        #var_dump($xml);
        $invoice_number = preg_replace("/[^0-9]/", '', $invoice["invoice"]->column_fields["invoice_no"]);
        $fileName = 'IT01687650992_' . sprintf('%05d', $invoice_number) . '.xml';
        $document = save_file($xml, strlen($xml), $fileName);

        $invoice['invoice']->save_related_module("Invoice",$invoice['invoice']->id,"Documents",$document->id);

        if ($debugLocation) {
            header("Location: index.php?module=Invoice&relatedModule=Documents&view=Detail&record=".$invoice['invoice']->id."&mode=showRelatedList&relationId=78&tab_label=Documents&app=".$app."");
        }

    } catch(Exception $e) {
        echo $e->getMessage();
    }
}

function postHttp($url, $post, $headers = null) {
	try {
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post) );
		if ($headers != null)
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$response = curl_exec($ch);

		if (curl_error($ch)) {
			trigger_error('Curl Error:' . curl_error($ch));
		}

		curl_close($ch);

		return $response;
	} catch(Exception $e) {

	}
}

function get_field_data($data, $name) {
	$config = getConfig();
	foreach ($config["fields"][$name] as $field) {
		try {
			$value = htmlspecialchars($data[$field]);
			if ($value) {
				return $value;
			}
		} catch(Exception $e) {
			echo $e;
		}
	}

	return "";
}

function serializzaCustomer($entity) {
	$ret="";
	$entity_fields = $entity->column_fields;

	$name = get_field_data($entity_fields, "name");
	$surname = get_field_data($entity_fields, "surname");
	$phone = get_field_data($entity_fields, "phone");
	$vat_number = get_field_data($entity_fields, "vat_number");
	$fiscal_code = get_field_data($entity_fields, "fiscal_code");

	$vat_type = get_field_data($entity_fields, "vat_type");
	$fe_customer_pec = get_field_data($entity_fields, "fe_customer_pec");
	$fe_destination_code = get_field_data($entity_fields, "fe_destination_code");

	$email = get_field_data($entity_fields, "email");
	$street = get_field_data($entity_fields, "street");
	$city = get_field_data($entity_fields, "city");
	$state = get_field_data($entity_fields, "state");
	$postal_code = get_field_data($entity_fields, "postal_code");
	$country = get_field_data($entity_fields, "country");
	$provincia = get_field_data($entity_fields, "provincia");

	$country = $country ?: $state;

	if ($vat_type) {
		$vat_type = explode(" -", $vat_type)[0];
	}

	$ret =		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
			"<Fattura24>\n".
			"	<Document>\n".
			"		<CustomerName>".($surname ? ($name." ".$surname) : $name)."</CustomerName>\n".
			"		<CustomerAddress>$street</CustomerAddress>\n".
			"		<CustomerPostcode>$postal_code</CustomerPostcode>\n".
			"		<CustomerCity>$city</CustomerCity>\n".
			"		<CustomerProvince>$provincia</CustomerProvince>\n".
			"		<CustomerCountry>$country</CustomerCountry>\n".
			"		<CustomerFiscalCode>$fiscal_code</CustomerFiscalCode>\n".
			"		<CustomerVatCode>$vat_number</CustomerVatCode>\n".
			"		<CustomerCellPhone>$phone</CustomerCellPhone>\n".
			"		<CustomerEmail>$email</CustomerEmail>\n".
      "		<VatType>".$vat_type."</VatType>\n".
      "		<FeCustomerPec>".$fe_customer_pec."</FeCustomerPec>\n".
      "		<FeDestinationCode>".$fe_destination_code."</FeDestinationCode>\n".
			"	</Document>\n".
			"</Fattura24>\n";

	return $ret;
}

function serializzaDocumento($fattura, $type) {
	$config = getConfig();

    $campo_partitaiva = get_columnname( $config['mapping']['org']['partitaiva']);
    $campo_codicefiscale = get_columnname( $config['mapping']['org']['codicefiscale']);
    $campo_provinciafatturazione = get_columnname( $config['mapping']['org']['provinciafatturazione'] );
	$campo_provinciaconsegna = get_columnname( $config['mapping']['org']['provinciaconsegna'] );
	$metodopagamento = $config['metodopagamento'];
	$iban = $config['iban'];
	$banca = $config['banca'];
	$send_email = $config['send_email'];

	$invoice_vet = $fattura["invoice"]->column_fields;
	$account_vet = $fattura["account"];
	$contact_vet = $fattura["contact"];

# Invoice
	$subject = htmlspecialchars($invoice_vet["subject"]);
    $sub_totale = htmlspecialchars($invoice_vet["hdnSubTotal"]);
	$totale = htmlspecialchars($invoice_vet["hdnGrandTotal"]);
	$iva_amount = htmlspecialchars($invoice_vet["tax1"]);
    if (!$iva_amount) {
        $iva_amount = htmlspecialchars($invoice_vet["tax8"]);
    }
	$tasse = $sub_totale * ($iva_amount / 100);
	$termini = htmlspecialchars($invoice_vet["terms_conditions"]);
	$data_pagamento = $invoice_vet['duedate'];

    $fepaymentcode = explode(" -", $invoice_vet["fepaymentcode"])[0];

# Customer
	if ($account_vet) {
		$entity_fields = $account_vet->column_fields;

		// $nome = htmlspecialchars($account_vet["accountname"]);
		// $phone = htmlspecialchars($account_vet["phone"]);
		// $piva = htmlspecialchars($account_vet["partitaiva"]);
		// $codicefiscale = htmlspecialchars($account_vet["codicefiscale"]);
		// $provinciafatturazione = htmlspecialchars($account_vet["provincia"]);
		// $provinciaconsegna = htmlspecialchars($account_vet["provinciaconsegna"]);

		// if ($type == "FE") {
		// 	$vattype = $account_vet["vattype"];
		// 	$fecustomerpec = htmlspecialchars($account_vet["fecustomerpec"]);
		// 	$fedestinationcode = htmlspecialchars($account_vet["fedestinationcode"]);
		// }

		// $email = htmlspecialchars($account_vet["email1"]);
		// $bill_street = htmlspecialchars($account_vet["bill_street"]);
		// $bill_city = htmlspecialchars($account_vet["bill_city"]);
		// $bill_state = htmlspecialchars($account_vet["bill_state"]);
		// $bill_code = htmlspecialchars($account_vet["bill_code"]);
		// $bill_country = htmlspecialchars($account_vet["bill_country"]);
		// $bill_pobox = htmlspecialchars($account_vet["bill_pobox"]);
		// 	$ship_street = htmlspecialchars($account_vet["ship_street"]);
		// 	$ship_city = htmlspecialchars($account_vet["ship_city"]);
		// 	$ship_state = htmlspecialchars($account_vet["ship_state"]);
		// 	$ship_code = htmlspecialchars($account_vet["ship_code"]);
		// 	$ship_country = htmlspecialchars($account_vet["ship_country"]);
		// 	$ship_pobox = htmlspecialchars($account_vet["ship_pobox"]);


		// if (!$bill_country) {
		// 	$bill_country = $bill_state;
		// }
	} else {
		$entity_fields = $contact_vet->column_fields;
	}

	$name = get_field_data($entity_fields, "name");
	$surname = get_field_data($entity_fields, "surname");
	$phone = get_field_data($entity_fields, "phone");
	$vat_number = get_field_data($entity_fields, "vat_number");
	$fiscal_code = get_field_data($entity_fields, "fiscal_code");
	$provincia_fatturazione = get_field_data($entity_fields, "provincia_fatturazione");
	$provincia_consegna = get_field_data($entity_fields, "provincia_consegna");

    $vat_type = get_field_data($entity_fields, "vat_type");
    $fe_customer_pec = get_field_data($entity_fields, "fe_customer_pec");
    $fe_destination_code = get_field_data($entity_fields, "fe_destination_code");

	$email = get_field_data($entity_fields, "email");
	$street = get_field_data($entity_fields, "street");
	$city = get_field_data($entity_fields, "city");
	$state = get_field_data($entity_fields, "state");
	$postal_code = get_field_data($entity_fields, "postal_code");
	$country = get_field_data($entity_fields, "country");
	// $bill_pobox = htmlspecialchars($entity_fields["bill_pobox"]);
		$ship_street = get_field_data($entity_fields, "ship_street");
		$ship_city = get_field_data($entity_fields, "ship_city");
		$ship_state = get_field_data($entity_fields, "ship_state");
		$ship_postal_code = get_field_data($entity_fields, "ship_postal_code");
		$ship_country = get_field_data($entity_fields, "ship_country");
		// $ship_pobox = htmlspecialchars($entity_fields["ship_pobox"]);

	$country = $country ?: $state;

    if ($vat_type) {
        $vat_type = explode(" -", $vat_type)[0];
        $vat_type = "<VatType>".$vat_type."</VatType>\n";
    }

    if ($fepaymentcode == "MP05") {
        $paymentdescript = "<PaymentMethodDescription>".$iban."</PaymentMethodDescription>\n";
    }

# Products
	$products = $fattura["products"];

	$ret =	"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
		"<Fattura24>\n".
		"	<Document>\n".
		"		<b><DocumentType>$type</DocumentType></b>\n".
		"		<CustomerName><![CDATA[".($surname ? ($name." ".$surname) : $name)."]]></CustomerName>\n".
		"		<CustomerAddress><![CDATA[$street]]></CustomerAddress>\n".
		"		<CustomerPostcode>$postal_code</CustomerPostcode>\n".
		"		<CustomerCity>$city</CustomerCity>\n".
		"		<CustomerProvince>$provincia_fatturazione</CustomerProvince>\n".
		"		<CustomerCountry>$country</CustomerCountry>\n".
		"		<CustomerFiscalCode>".$fiscal_code."</CustomerFiscalCode>\n".
		"		<CustomerVatCode>$vat_number</CustomerVatCode>\n".
		"		<CustomerCellPhone>$phone</CustomerCellPhone>\n".
		"		<CustomerEmail>$email</CustomerEmail>\n";

    #if ($type == "FE") {
        $ret = $ret.
           "		<FeCustomerPec>".$fe_customer_pec."</FeCustomerPec>\n".
            "		<FeDestinationCode>".$fe_destination_code."</FeDestinationCode>\n".
            "		<FePaymentCode>".$fepaymentcode."</FePaymentCode>\n".
            $paymentdescript.
            $vat_type;
    /*} else {
        $ret = $ret.
            "		<DeliveryName>$name</DeliveryName>\n".
            "		<DeliveryAddress>".($ship_street ?: $street)."</DeliveryAddress>\n".
            "		<DeliveryPostcode>".($ship_postal_code ?: $postal_code)."</DeliveryPostcode>\n".
            "		<DeliveryCity>".($ship_city ?: $city)."</DeliveryCity>\n".
            "		<DeliveryProvince>$provincia_consegna</DeliveryProvince>\n".
            "		<DeliveryCountry>".($ship_country ?: $country)."</DeliveryCountry>\n".
            "		<PaymentMethodDescription>".$iban."</PaymentMethodDescription>\n".
            "		<UpdateStorage>1</UpdateStorage>\n".
    		"		<F24OrderId></F24OrderId>\n".
    		"		<IdTemplate></IdTemplate>\n".
    		"		<Payments>\n".
    		"			<Payment>\n".
    		"				<Date>".$data_pagamento."</Date>\n".
    		"				<Amount>".number_format($totale,2,".","")."</Amount>\n".
    		"				<Paid>false</Paid>\n".
    		"			</Payment>\n".
    		"		</Payments>\n";
    }*/

	$ret = $ret.
		"		<Object><![CDATA[$subject]]></Object>\n".
		"		<TotalWithoutTax>".number_format($sub_totale,2,".","")."</TotalWithoutTax>\n".
		"		<PaymentMethodName>".$metodopagamento."</PaymentMethodName>\n".
		"		<VatAmount>".number_format($tasse,2,".","")."</VatAmount>\n".
		"		<Total>".number_format($totale,2,".","")."</Total>\n".
		"		<FootNotes>$termini</FootNotes>\n".
		"		<SendEmail>$send_email</SendEmail>\n".
		"		<Rows>\n";

	$count = 1;
	foreach($products as $ps) {
		$productid = $ps["hdnProductcode$count"];
		$quantity = $ps["qty$count"];
		$price = $ps["listPrice$count"];
		$comment = $ps["comment$count"];
        // $iva = number_format($ps["taxes"][0]["percentage"],0,"","");
        // $iva = number_format($ps["taxTotal$count"][0]["percentage"],0,"","");
		// $iva = number_format($ps["taxes"][0]["percentage"],0,"","");

        $iva = number_format($iva_amount,0,"","");


        $fevat = "";

        if ($type == "FE") {
            $adb = PearDatabase::getInstance();
    		$sql = "select fevatnature from vtiger_products where product_no = \"".$productid."\"";
            $res = $adb->pquery($sql, array());
            $fevatnature = "";
            for ($i = 0; $i < $adb->num_rows($res); $i++) {
                $fevatnature = $adb->query_result($res, $i, "fevatnature");
                $fevatnature = explode(" -", $fevatnature)[0];
            }

            if ($iva == "0") {
                $fevat = "<FeVatNature>".$fevatnature."</FeVatNature>\n";
            }
        }

		if ($productid == null || $productid == "")
			continue;

		if ($comment == "")
			$comment = "NESSUN COMMENTO";

		$ret =	$ret.
			"			<Row>\n".
			"				<Code>$productid</Code>\n".
			"				<Description><![CDATA[$comment]]></Description>\n".
			"				<Qty>$quantity</Qty>\n".
			"				<Um></Um>\n".
			"				<Price>".number_format($price, 2, ".", "")."</Price>\n".
			"				<Discounts></Discounts>\n".
			"				<VatCode>$iva</VatCode>\n".
			"				<VatDescription>IVA ".$iva."%</VatDescription>\n".
            "               ".$fevat."".
			"			</Row>\n";
			$count++;

	}

	$ret=	$ret.
		"		</Rows>\n".
		"	</Document>\n".
		"</Fattura24>";

		return $ret;
}

function genera_xml_fattura($fattura, $type) {
	$config = getConfig();

    $campo_partitaiva = get_columnname( $config['mapping']['org']['partitaiva']);
    $campo_codicefiscale = get_columnname( $config['mapping']['org']['codicefiscale']);
    $campo_provinciafatturazione = get_columnname( $config['mapping']['org']['provinciafatturazione'] );
	$campo_provinciaconsegna = get_columnname( $config['mapping']['org']['provinciaconsegna'] );
	$metodopagamento = $config['metodopagamento'];
	$iban = $config['iban'];
	$send_email = $config['send_email'];

	$invoice_vet = $fattura["invoice"]->column_fields;
	$account_vet = $fattura["account"];
	$contact_vet = $fattura["contact"];

# Invoice
	$subject = htmlspecialchars($invoice_vet["subject"]);
    $sub_totale = htmlspecialchars($invoice_vet["hdnSubTotal"]);
	$totale = htmlspecialchars($invoice_vet["hdnGrandTotal"]);
	$iva_amount = htmlspecialchars($invoice_vet["tax1"]);
    if (!$iva_amount) {
        $iva_amount = htmlspecialchars($invoice_vet["tax8"]);
    }
	$tasse = $sub_totale * ($iva_amount / 100);
	$termini = htmlspecialchars($invoice_vet["terms_conditions"]);
	$data_pagamento = $invoice_vet['duedate'];

    $fepaymentcode = explode(" -", $invoice_vet["fepaymentcode"])[0];

# Customer
	if ($account_vet) {
		$entity_fields = $account_vet->column_fields;

		// $nome = htmlspecialchars($account_vet["accountname"]);
		// $phone = htmlspecialchars($account_vet["phone"]);
		// $piva = htmlspecialchars($account_vet["partitaiva"]);
		// $codicefiscale = htmlspecialchars($account_vet["codicefiscale"]);
		// $provinciafatturazione = htmlspecialchars($account_vet["provincia"]);
		// $provinciaconsegna = htmlspecialchars($account_vet["provinciaconsegna"]);

		// if ($type == "FE") {
		// 	$vattype = $account_vet["vattype"];
		// 	$fecustomerpec = htmlspecialchars($account_vet["fecustomerpec"]);
		// 	$fedestinationcode = htmlspecialchars($account_vet["fedestinationcode"]);
		// }

		// $email = htmlspecialchars($account_vet["email1"]);
		// $bill_street = htmlspecialchars($account_vet["bill_street"]);
		// $bill_city = htmlspecialchars($account_vet["bill_city"]);
		// $bill_state = htmlspecialchars($account_vet["bill_state"]);
		// $bill_code = htmlspecialchars($account_vet["bill_code"]);
		// $bill_country = htmlspecialchars($account_vet["bill_country"]);
		// $bill_pobox = htmlspecialchars($account_vet["bill_pobox"]);
		// 	$ship_street = htmlspecialchars($account_vet["ship_street"]);
		// 	$ship_city = htmlspecialchars($account_vet["ship_city"]);
		// 	$ship_state = htmlspecialchars($account_vet["ship_state"]);
		// 	$ship_code = htmlspecialchars($account_vet["ship_code"]);
		// 	$ship_country = htmlspecialchars($account_vet["ship_country"]);
		// 	$ship_pobox = htmlspecialchars($account_vet["ship_pobox"]);


		// if (!$bill_country) {
		// 	$bill_country = $bill_state;
		// }
	} else {
		$entity_fields = $contact_vet->column_fields;
	}
    #print_r($invoice_vet->column_fields); die();
	$name = get_field_data($entity_fields, "name");
	$surname = get_field_data($entity_fields, "surname");
	$phone = get_field_data($entity_fields, "phone");
	$vat_number = get_field_data($entity_fields, "vat_number");
	$fiscal_code = get_field_data($entity_fields, "fiscal_code");
	$provincia_fatturazione = get_field_data($entity_fields, "provincia_fatturazione");
	$provincia_consegna = get_field_data($entity_fields, "provincia_consegna");
#print_r($fattura); die();
    $vat_type = get_field_data($entity_fields, "vat_type");
    $fe_customer_pec = get_field_data($entity_fields, "fe_customer_pec");
    $fe_destination_code = get_field_data($entity_fields, "fe_destination_code");

	$email = get_field_data($entity_fields, "email");
	$street = get_field_data($entity_fields, "street");
	$city = get_field_data($entity_fields, "city");
	$state = get_field_data($entity_fields, "state");
	$postal_code = get_field_data($entity_fields, "postal_code");
	$country = get_field_data($entity_fields, "country");
	// $bill_pobox = htmlspecialchars($entity_fields["bill_pobox"]);
		$ship_street = get_field_data($entity_fields, "ship_street");
		$ship_city = get_field_data($entity_fields, "ship_city");
		$ship_state = get_field_data($entity_fields, "ship_state");
		$ship_postal_code = get_field_data($entity_fields, "ship_postal_code");
		$ship_country = get_field_data($entity_fields, "ship_country");
		// $ship_pobox = htmlspecialchars($entity_fields["ship_pobox"]);

    $iban = get_field_data($invoice_vet, 'iban');
		 $banca = get_field_data($invoice_vet, 'banca');
    $iban_array = explode('-', $iban);
    $iban = str_replace(" ", "", $iban_array[1]);
    $codice_pagamento = get_field_data($invoice_vet, 'codice_pagamento');
    $codice_pagamento = preg_replace("/[^MP0-9]/", '', $codice_pagamento);
    $condizioni_pagamento = get_field_data($invoice_vet, 'condizioni_pagamento');
    $condizioni_pagamento = preg_replace("/[^TP0-9]/", '', $condizioni_pagamento);
    $invoicedate = get_field_data($invoice_vet, 'invoice_date');
    //$invoicenumber = preg_replace("/[^0-9]/", '', get_field_data($invoice_vet, 'invoice_no'));
    $invoicenumber = preg_replace("/[^0-9]/", '-', get_field_data($invoice_vet, 'invoice_no'));
    $invoicenumberCN = preg_replace("/[^0-9]/", '/', get_field_data($invoice_vet, 'invoice_no'));
    #print_r($fattura); die();
	$country = $country ?: $state;
	$country = 'IT'; # sono tutti italiani

    if ($vat_type) {
        $vat_type = explode(" -", $vat_type)[0];
        #$vat_type = "<VatType>".$vat_type."</VatType>\n";
    }

    #if ($fepaymentcode == "MP05") {
    #    $paymentdescript = "<PaymentMethodDescription>".$iban."</PaymentMethodDescription>\n";
    #}

# Products
	$products = $fattura["products"];

	################
	### XML FILL ###
	################
	$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

    $bool_PEC = false;
    if(strlen($fe_destination_code) == 6){
        $formato_trasmissione = 'FPA12';
    }else{
        $formato_trasmissione = 'FPR12';
        if($fe_destination_code == '0000000'){
            $bool_PEC = true;
        }
    }

    # xml (w NS)
	$xml .= "<p:FatturaElettronica xmlns:ds='http://www.w3.org/2000/09/xmldsig#' xmlns:p='http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' versione='{$formato_trasmissione}' xsi:schemaLocation='http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2 http://www.fatturapa.gov.it/export/fatturazione/sdi/fatturapa/v1.2/Schema_del_file_xml_FatturaPA_versione_1.2.xsd'>\n";


	# header | REQUIRED & UNIQUE
	$xml .= "<FatturaElettronicaHeader>\n";

	if($fe_destination_code == ''){
        $fe_destination_code = '0000000';
    }

    $bool_Azienda = ($vat_number != '') ? true : false;
    $bool_Estero = false;
    if($country != 'IT'){
        $bool_Estero = true;
        $fe_destination_code = 'XXXXXXX';
        $postal_code = '00000';
        $bool_CessionarioProvincia = false;
    }else{
        $bool_CessionarioProvincia = (!empty($provincia_fatturazione)) ? true : false;
    }

	# REQUIRED
	$xml .= "<DatiTrasmissione>\n";
	# REQUIRED
	$xml .= "<IdTrasmittente>\n";
	# REQUIRED::ISO 3166-1 alpha-2 code
	$xml .= "<IdPaese>IT</IdPaese>\n"; # paese che assegna id fiscale
	# REQUIRED::[:alnum:]{,28}
	$xml .= "<IdCodice>01687650992</IdCodice>\n"; # id fiscale (cf or similia)
	$xml .= "</IdTrasmittente>\n";
	# REQUIRED::[:alnum:]{,10}
	$xml .= "<ProgressivoInvio>{$invoicenumber}</ProgressivoInvio>\n"; # identificativo progressivo univoco assegnato liberamente
	# REQUIRED::[:alnum:]{5}
	$xml .= "<FormatoTrasmissione>{$formato_trasmissione}</FormatoTrasmissione>\n"; # FPA12 -> verso PA v1.2 ; FPR12 -> verso privati v1.2
	# REQUIRED::[:alnum:]{6,7}
	$xml .= "<CodiceDestinatario>{$fe_destination_code}</CodiceDestinatario>\n"; # vs PA -> {6} da wwww.indicepa.gov.it > CodiceUfficio ; vs OTH -> {7} da sdi ; vs PEC(oth) -> '0000000'
	#if ($xml_not_only_required) {
	#$xml .= "<ContattiTrasmittente>";# ::[:alnum:]{5,12}
	#$xml .= "<Telefono></Telefono>";# ::[:alnum:]{7,256}
	#$xml .= "<Email></Email>";
	#$xml .= "</ContattiTrasmittente>";
	#}
	if ( $bool_PEC && !empty($fe_customer_pec) ) {
		# ::[:alnum:]{7,256}
		$xml .= "<PECDestinatario>{$fe_customer_pec}</PECDestinatario>\n"; # ONLY@CodiceDestinatario = '0000000'
	}
	$xml .= "</DatiTrasmissione>\n";

	# REQUIRED
	$xml .= "<CedentePrestatore>\n";
	# REQUIRED
	$xml .= "<DatiAnagrafici>\n";
	# REQUIRED
	$xml .= "<IdFiscaleIVA>\n";
	# REQUIRED::ISO 3166-1 alpha-2 code
	$xml .= "<IdPaese>IT</IdPaese>\n"; # paese che assegna id fiscale
	# REQUIRED::[:alnum:]{,28}
	$xml .= "<IdCodice>01687650992</IdCodice>\n"; # id fiscale (cf or similia)
	$xml .= "</IdFiscaleIVA>\n";
	#if ($xml_not_only_required) {
	# ::[:alnum:]{11-16}
	$xml .= "<CodiceFiscale>01687650992</CodiceFiscale>\n";
	#$xml .= "<CodiceFiscale>{$values['cedente_CodiceFiscale']}</CodiceFiscale>";
	#}
	# REQUIRED
	$xml .= "<Anagrafica>\n";
	#if ($bool_Denominazione) {
	# REQUIRED || {Nome + Cognome} ::[:alnum:]{,80}
	$xml .= "<Denominazione>Idroblu srl</Denominazione>\n";
	#} else {
	# {REQUIRED w Cognome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Nome>{$values['cedente_Nome']}</Nome>";
	# {REQUIRED w Nome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Cognome>{$values['cedente_Cognome']}</Cognome>";
	#}
	#if ($xml_not_only_required) {
	# ::[:alnum:]{2,10}
	#$xml .= "<Titolo></Titolo>";
	# ::[:alnum:]{13,17}
	#$xml .= "<CodEORI></CodEORI>";
	#}
	$xml .= "</Anagrafica>\n";
	#if ($xml_not_only_required) {
	# ::[:alnum:]{,60}
	#$xml .= "<AlboProfessionale></AlboProfessionale>"; # nome dell'albo di appartenenza
	# ::[:alnum:]{2}
	#$xml .= "<ProvinciaAlbo></ProvinciaAlbo>";
	# ::[:alnum:]{,60}
	#$xml .= "<NumeroIscrizioneAlbo></NumeroIscrizioneAlbo>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataIscrizioneAlbo></DataIscrizioneAlbo>";
	#}
	# REQUIRED::[:alnum:]{4}
	$xml .= "<RegimeFiscale>RF01</RegimeFiscale>\n"; # {RF01 ~ RF19} no RF03 ; v. doc. p. 38-39
	$xml .= "</DatiAnagrafici>\n";
	# REQUIRED
	$xml .= "<Sede>\n";
	# REQUIRED::[:alnum:]{,60}
	$xml .= "<Indirizzo>Via Michele Novaro,30r</Indirizzo>\n";
	#if ( $bool_CedenteNumeroCivico ) {
		# ::[:alnum:]{,8}
	#	$xml .= "<NumeroCivico>{$values['cedente_NumeroCivico']}</NumeroCivico>\n";
	#}
	# REQUIRED::[0-9]{5}
	$xml .= "<CAP>16143</CAP>\n";
	# REQUIRED::[:alnum:]{,60}
	$xml .= "<Comune>Genova</Comune>\n";
	#if ( $bool_CedenteProvincia ) {
		# ::[:alnum:]{2}
	#	$xml .= "<Provincia>{$values['cedente_Provincia']}</Provincia>\n";
	#}
	# REQUIRED::ISO 3166-1 alpha-2 code
	$xml .= "<Nazione>IT</Nazione>\n";
	$xml .= "</Sede>\n";
	#if ($xml_not_only_required) {
	#$xml .= "<StabileOrganizzazione>";
	# @ifrequired::[:alnum:]{,60}
	#$xml .= "<Indirizzo></Indirizzo>";
	# ::[:alnum:]{,8}
	#$xml .= "<NumeroCivico></NumeroCivico>";
	# @ifrequired::[0-9]{5}
	#$xml .= "<CAP></CAP>";
	# @ifrequired::[:alnum:]{,60}
	#$xml .= "<Comune></Comune>";
	# ::[:alnum:]{2}
	#$xml .= "<Provincia></Provincia>";
	# @ifrequired::ISO 3166-1 alpha-2 code
	#$xml .= "<Nazione></Nazione>";
	#$xml .= "</StabileOrganizzazione>";
	#}
	$xml .= "<IscrizioneREA>\n";
	# @ifrequired::[:alnum:]{2}
	$xml .= "<Ufficio>GE</Ufficio>\n";
	# @ifrequired::[:alnum:]{,20}
	$xml .= "<NumeroREA>428423</NumeroREA>\n";
	# ::[0-9.]{4,15}
	$xml .= "<CapitaleSociale>18750.00</CapitaleSociale>\n";
	# ::[:alnum:]{2}
	$xml .= "<SocioUnico>SM</SocioUnico>\n"; # SU -> socio unico ; SM -> non socio unico
	# @ifrequired::[:alnum:]{2}
	$xml .= "<StatoLiquidazione>LN</StatoLiquidazione>\n"; # LS -> stato di liquidazione ; LN -> non stato di liquidazione
	$xml .= "</IscrizioneREA>\n";
	#if ($xml_not_only_required) {
	#$xml .= "<Contatti>";
	# ::[:alnum:]{5,12}
	#$xml .= "<Telefono></Telefono>";
	# ::[:alnum:]{5,12}
	#$xml .= "<Fax></Fax>";
	# ::[:alnum:]{7,256}
	#$xml .= "<Email></Email>";
	#$xml .= "</Contatti>";
	# ::[:alnum:]{,20}
	#$xml .= "<RiferimentoAmministrazione></RiferimentoAmministrazione>";
	#}
	$xml .= "</CedentePrestatore>\n";

	#if ($xml_not_only_required) {
	#$xml .= "<RappresentanteFiscale>";
	# @ifrequired
	#$xml .= "<DatiAnagrafici>";
	# @ifrequired
	#$xml .= "<IdFiscaleIVA>";
	# @ifrequired::ISO 3166-1 alpha-2 code
	#$xml .= "<IdPaese></IdPaese>"; # paese che assegna id fiscale
	# @ifrequired::[:alnum:]{,28}
	#$xml .= "<IdCodice></IdCodice>"; # id fiscale (cf or similia)
	#$xml .= "</IdFiscaleIVA>";
	# ::[:alnum:]{11,16}
	#$xml .= "<CodiceFiscale></CodiceFiscale>";
	# @ifrequired
	#$xml .= "<Anagrafica>";
	# #ifrequired || {Nome + Cognome} ::[:alnum:]{,80}
	#$xml .= "<Denominazione></Denominazione>";
	# {@ifrequired w Cognome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Nome></Nome>";
	# {@ifrequired w Nome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Cognome></Cognome>";
	# ::[:alnum:]{2,10}
	#$xml .= "<Titolo></Titolo>";
	# ::[:alnum:]{13,17}
	#$xml .= "<CodEORI></CodEORI>";
	#$xml .= "</Anagrafica>";
	#$xml .= "</DatiAnagrafici>";
	#$xml .= "</RappresentanteFiscale>";
	#}



	# REQUIRED
	$xml .= "<CessionarioCommittente>\n";
	# REQUIRED
	$xml .= "<DatiAnagrafici>\n";
	if ( $bool_Azienda or $bool_Estero ) {
	    $idCodice = ($bool_Azienda) ? $vat_number : $fiscal_code;

		$xml .= "<IdFiscaleIVA>\n";
		# @ifrequired::ISO 3166-1 alpha-2 code
		$xml .= "<IdPaese>{$country}</IdPaese>\n"; # paese che assegna id fiscale
		# @ifrequired::[:alnum:]{,28}
		$xml .= "<IdCodice>{$idCodice}</IdCodice>\n"; # id fiscale (cf or similia)
		$xml .= "</IdFiscaleIVA>\n";
	} else {
		# ::[:alnum:]{11,16}
		$xml .= "<CodiceFiscale>" . strtoupper( $fiscal_code ) . "</CodiceFiscale>\n";
	}
	# REQUIRED

    #$surname ? ($name." ".$surname) : $name
	$xml .= "<Anagrafica>\n";
    //print Amministratore Name from account data
    $amministratoreName = '';
    if ($account_vet) {
		$entity_fields_Acc = $account_vet->column_fields;
        $amministratoreName = $entity_fields_Acc['accountname'];
        if(isRecordExists($entity_fields_Acc['amministratoriid'])){
            $amministratoreNameArr = getEntityName('Amministratori', $entity_fields_Acc['amministratoriid']);
            $amministratoreName .= ' c/o '.html_entity_decode($amministratoreNameArr[$entity_fields_Acc['amministratoriid']], ENT_QUOTES);
        }

    }
	#if ( $bool_Azienda ) {
	if ( $amministratoreName !='' ) {
		# REQUIRED || {Nome + Cognome} ::[:alnum:]{,80}
		#$xml .= "<Denominazione>{$name}</Denominazione>\n";
        if(mb_strlen($amministratoreName) > 80){
            $amministratoreName = mb_substr($amministratoreName, 0, 80);
        }
		$xml .= "<Denominazione>".$amministratoreName."</Denominazione>\n";
	} else {
		# {REQUIRED w Cognome} || Denominazione ::[:alnum:]{,60}
		$xml .= "<Nome>{$name}</Nome>\n";
		# {REQUIRED w Nome} || Denominazione ::[:alnum:]{,60}
		$xml .= "<Cognome>{$surname}</Cognome>\n";
	}
	# ::[:alnum:]{2,10}
	#$xml .= "<Titolo></Titolo>";
	# ::[:alnum:]{13,17}
	#$xml .= "<CodEORI></CodEORI>";
	$xml .= "</Anagrafica>\n";
	$xml .= "</DatiAnagrafici>\n";
	# REQUIRED
	$xml .= "<Sede>\n";
	# REQUIRED::[:alnum:]{,60}
	$xml .= "<Indirizzo>{$street}</Indirizzo>\n";
	#if ( ! empty( $values['cessionario_NumeroCivico'] ) ) {
		# ::[:alnum:]{,8}
	#	$xml .= "<NumeroCivico>{$values['cessionario_NumeroCivico']}</NumeroCivico>\n";
	#}
	# REQUIRED::[0-9]{5}
	$xml .= "<CAP>{$ship_postal_code}</CAP>\n";
	# REQUIRED::[:alnum:]{,60}
	$xml .= "<Comune>{$city}</Comune>\n";
	if ( $bool_CessionarioProvincia ) {
		# ::[:alnum:]{2}
		$xml .= "<Provincia>{$provincia_fatturazione}</Provincia>\n";
	}
	# REQUIRED::ISO 3166-1 alpha-2 code
	$xml .= "<Nazione>{$country}</Nazione>\n";
	$xml .= "</Sede>\n";
	$xml .= "</CessionarioCommittente>\n";
	$xml .= "</FatturaElettronicaHeader>\n";
	# /header


	### //////////////////// ###

	# body | REQUIRED & N-ABLE{1-inf} (se inviato lotto di fatture)
	$xml .= "<FatturaElettronicaBody>\n";

	# REQUIRED
	$xml .= "<DatiGenerali>\n";
	# REQUIRED
	$xml .= "<DatiGeneraliDocumento>\n";
	# REQUIRED::[:alnum:]{4}
	$xml .= "<TipoDocumento>TD01</TipoDocumento>\n"; # TD01 -> fattura ; TD02 -> Acconto/Anticipo su fattura ; TD03 -> Acconto/Anticipo su parcella ; TD04 -> Nota di Credito ; TD05 -> Nota di Debito ; TD06 -> Parcella
	# REQUIRED::ISO 4217 alpha-3:2001
	$xml .= "<Divisa>EUR</Divisa>\n"; # EUR ; USD ; GBP ; CZK ; ...
	# REQUIRED::ISO 8601:2004 (YYYY-MM-DD)
	$xml .= "<Data>$invoicedate</Data>\n";
	# REQUIRED::[:alnum:]{,20}
	#$xml .= "<Numero>{$values['fattura_NumeroOrdine']}</Numero>\n";
	#$xml .= "<Numero>".date('Y')."/{$invoicenumber}</Numero>\n";
	$xml .= "<Numero>{$invoicenumberCN}</Numero>\n";

	$xml .= "<DatiRitenuta>\n";
	# @ifrequired::[:alnum:]{4}
	$xml .= "<TipoRitenuta>RT02</TipoRitenuta>\n"; # RT01 -> ritenuta persone fisiche ; RT02 -> ritenuta persone giuridiche
	# @ifrequired::[0-9.]{4,15}
    //Get Deducted Taxes
    $invoiceId = $invoice_vet['record_id'];
    $recordModel = Inventory_Record_Model::getInstanceById($invoiceId, 'Invoice');
    $products = $recordModel->getProducts();
    /* echo "<pre>";
    print_r($products[1]['final_details']['deductTaxes'][4]['percentage']);+
    echo "</pre>";die; */
	$xml .= "<ImportoRitenuta>".$products[1]['final_details']['deductTaxesTotalAmount']."</ImportoRitenuta>\n";
	# @ifrequired::[0-9.]{4,6}
	$xml .= "<AliquotaRitenuta>".number_format($products[1]['final_details']['deductTaxes'][4.00]['percentage'], 2, '.', '')."</AliquotaRitenuta>\n";
	# @ifrequired::[:alnum:]{,2}
	$xml .= "<CausalePagamento>W</CausalePagamento>\n"; # v. 770S su istruzioni compilazione
	$xml .= "</DatiRitenuta>\n";
	#$xml .= "<DatiBollo>";
	# @ifrequired::[:alnum:]{2}
	#$xml .= "<BolloVirtuale></BolloVirtuale>"; # SI -> bollo assolto per decreto MEF 14/06/2014
	# @ifrequired::[0-9.]{4,15}
	#$xml .= "<ImportoBollo></ImportoBollo>";
	#$xml .= "</DatiBollo>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiCassaPrevidenziale>";
	# @ifrequired::[:alnum:]{4}
	#$xml .= "<TipoCassa></TipoCassa>"; # {TC01 ~ TC22} ; v. doc. p. 53-54
	# @ifrequired::[0-9.]{4,6}
	#$xml .= "<AlCassa></AlCassa>";
	# @ifrequired::[0-9.]{4,15}
	#$xml .= "<ImportoContributoCassa></ImportoContributoCassa>";
	# ::[0-9.]{4,15}
	#$xml .= "<ImponibileCassa></ImponibileCassa>";
	# @ifrequired::[0-9.]{4,6}
	#$xml .= "<AliquotaIVA></AliquotaIVA>";
	# ::[a-zA-Z]{2}
	#$xml .= "<Ritenuta>SI</Ritenuta>\n"; # SI -> contributo cassa soggetto a ritenuta
	# ::[:alnum:]{2}
	#$xml .= "<Natura></Natura>"; # {N1 ~ N7} ; v. doc. p. 55
	# ::[:alnum:]{,20}
	#$xml .= "<RiferimentoAmministrazione></RiferimentoAmministrazione>";
	#$xml .= "</DatiCassaPrevidenziale>";
	# N-ABLE{0-inf}
	#$xml .= "<ScontoMaggiorazione>";
	# @ifrequired::[:alnum:]{2}
	#$xml .= "<Tipo></Tipo>"; # SC -> sconto ; MG -> maggiorazione
	# ::[0-9]{4,6}
	#$xml .= "<Percentuale></Percentuale>";
	# ::[0-9.]{4,15}
	#$xml .= "<Importo></Importo>";
	#$xml .= "</ScontoMaggiorazione>";
	# ::[0-9.]{4,15}
	$xml .= "<ImportoTotaleDocumento>".number_format($totale,2,".","")."</ImportoTotaleDocumento>\n";
	# ::[0-9.]{4,15}
	#$xml .= "<Arrotondamento></Arrotondamento>";
	# N-ABLE{0-inf}::[:alnum:]{,200}
	#$xml .= "<Causale></Causale>";
	# ::[:alnum:]{2}
	#$xml .= "<Art73></Art73>"; # SI -> documento secondo DM e art. 73 DPR 633/72
	$xml .= "</DatiGeneraliDocumento>\n";
	# N-ABLE{0-inf}
	#$xml .= "<DatiOrdineAcquisto>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<IdDocumento></IdDocumento>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumItem></NumItem>";
	# ::[:alnum:]{,100}
	#$xml .= "<CodiceCommessaConvenzione></CodiceCommessaConvenzione>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCUP></CodiceCUP>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCIG></CodiceCIG>";
	#$xml .= "</DatiOrdineAcquisto>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiContratto>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<IdDocumento></IdDocumento>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumItem></NumItem>";
	# ::[:alnum:]{,100}
	#$xml .= "<CodiceCommessaConvenzione></CodiceCommessaConvenzione>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCUP></CodiceCUP>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCIG></CodiceCIG>";
	#$xml .= "</DatiContratto>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiConvenzione>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<IdDocumento></IdDocumento>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumItem></NumItem>";
	# ::[:alnum:]{,100}
	#$xml .= "<CodiceCommessaConvenzione></CodiceCommessaConvenzione>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCUP></CodiceCUP>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCIG></CodiceCIG>";
	#$xml .= "</DatiConvenzione>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiRicezione>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<IdDocumento></IdDocumento>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumItem></NumItem>";
	# ::[:alnum:]{,100}
	#$xml .= "<CodiceCommessaConvenzione></CodiceCommessaConvenzione>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCUP></CodiceCUP>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCIG></CodiceCIG>";
	#$xml .= "</DatiRicezione>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiFattureCollegate>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<IdDocumento></IdDocumento>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumItem></NumItem>";
	# ::[:alnum:]{,100}
	#$xml .= "<CodiceCommessaConvenzione></CodiceCommessaConvenzione>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCUP></CodiceCUP>";
	# ::[:alnum:]{,15}
	#$xml .= "<CodiceCIG></CodiceCIG>";
	#$xml .= "</DatiFattureCollegate>";
	#$xml .= "<DatiSAL>"; # ONLY@ fattura per stato di avanzamento
	# @ifrequired::[0-9]{,3}
	#$xml .= "<RiferimentoFase></RiferimentoFase>";
	#$xml .= "</DatiSAL>";
	# N-ABLE{0-inf}
	#$xml .= "<DatiDDT>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<NumeroDDT></NumeroDDT>";
	# @ifrequired::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataDDT></DataDDT>";
	# N-ABLE{0-inf}::[0-9]{,4}
	#$xml .= "<RiferimentoNumeroLinea></RiferimentoNumeroLinea>";
	#$xml .= "</DatiDDT>";
	#$xml .= "<DatiTrasporto>";
	#$xml .= "<DatiAnagraficiVettore>";
	# @ifrequired
	#$xml .= "<IdFiscaleIVA>";
	# @ifrequired::ISO 3166-1 alpha-2 code
	#$xml .= "<IdPaese></IdPaese>"; # paese che assegna id fiscale
	# @ifrequired::[:alnum:]{,28}
	#$xml .= "<IdCodice></IdCodice>"; # id fiscale (cf or similia)
	#$xml .= "</IdFiscaleIVA>";
	# ::[:alnum:]{11,16}
	#$xml .= "<CodiceFiscale></CodiceFiscale>";
	# @ifrequired
	#$xml .= "<Anagrafica>";
	# #ifrequired || {Nome + Cognome} ::[:alnum:]{,80}
	#$xml .= "<Denominazione></Denominazione>";
	# {@ifrequired w Cognome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Nome></Nome>";
	# {@ifrequired w Nome} || Denominazione ::[:alnum:]{,60}
	#$xml .= "<Cognome></Cognome>";
	# ::[:alnum:]{2,10}
	#$xml .= "<Titolo></Titolo>";
	# ::[:alnum:]{13,17}
	#$xml .= "<CodEORI></CodEORI>";
	#$xml .= "</Anagrafica>";
	# ::[:alnum:]{,20}
	#$xml .= "<NumeroLicenzaGuida></NumeroLicenzaGuida>";
	#$xml .= "</DatiAnagraficiVettore>";
	# ::[:alnum:]{,80}
	#$xml .= "<MezzoTrasporto></MezzoTrasporto>";
	# ::[:alnum:]{,100}
	#$xml .= "<CausaleTrasporto></CausaleTrasporto>";
	# ::[0-9]{,4}
	#$xml .= "<NumeroColli></NumeroColli>";
	# ::[:alnum:]{,100}
	#$xml .= "<Descrizione></Descrizione>";
	# ::[:alnum:]{,10}
	#$xml .= "<UnitaMisuraPeso></UnitaMisuraPeso>";
	# ::[0-9.]{4,7}
	#$xml .= "<PesoLordo></PesoLordo>";
	# ::[0-9.]{4,7}
	#$xml .= "<PesoNetto></PesoNetto>";
	# ::ISO 8601:2004 (YYYY-MM-DDTHH:MM:SS)
	#$xml .= "<DataOraRitiro></DataOraRitiro>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataInizioTrasporto></DataInizioTrasporto>";
	# ::[:alnum:]{3}
	#$xml .= "<TipoResa></TipoResa>"; # standard ICC (Camera di Commercio Internazionale)
	#$xml .= "<IndirizzoResa>";
	# @ifrequired::[:alnum:]{,60}
	#$xml .= "<Indirizzo></Indirizzo>";
	# ::[:alnum:]{,8}
	#$xml .= "<NumeroCivico></NumeroCivico>";
	# @ifrequired::[0-9]{5}
	#$xml .= "<CAP></CAP>";
	# @ifrequired::[:alnum:]{,60}
	#$xml .= "<Comune></Comune>";
	# ::[:alnum:]{2}
	#$xml .= "<Provincia></Provincia>";
	# @ifrequired::ISO 3166-1 alpha-2 code
	#$xml .= "<Nazione></Nazione>";
	#$xml .= "</IndirizzoResa>";
	# ::ISO 8601:2004 (YYYY-MM-DDTHH:MM:SS)
	#$xml .= "<DataOraConsegna></DataOraConsegna>";
	#$xml .= "</DatiTrasporto>";
	#$xml .= "<FatturaPrincipale>";
	# @ifrequired::[:alnum:]{,20}
	#$xml .= "<NumeroFatturaPrincipale></NumeroFatturaPrincipale>";
	# @ifrequired::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataFatturaPrincipale></DataFatturaPrincipale>";
	#$xml .= "</FatturaPrincipale>";
	$xml .= "</DatiGenerali>\n";

	# REQUIRED
	$xml               .= "<DatiBeniServizi>\n";
	$n_line            = 1;

	$array_iva = Array();

	#print_r($products);
	#die();
	foreach ( $products as $line ) {
		# Initialize array field (if)
        $quantity = number_format($line["qty$n_line"], 2, '.', '');
        $price = number_format($line["listPrice$n_line"], 2, '.', '');
        #$comment = $line["comment$n_line"];
        $productName = $line["productName$n_line"];

        $prezzo_totale = number_format($line["productTotal$n_line"], 2, '.', '');
        #$aliquota_iva = number_format($line["cf_1351"][0]["percentage"], 2, '.', '');
        $aliquota_iva = number_format($invoice_vet["aliquota_iva"], 2, '.', '');
        $productId = $line["hdnProductId$n_line"];

        if(!isset($array_iva[$aliquota_iva])){
            $array_iva[$aliquota_iva] = Array("imponibile" => 0, "euro_iva" => 0);
        }
        $array_iva[$aliquota_iva]["imponibile"] += $prezzo_totale;
        $array_iva[$aliquota_iva]["euro_iva"] += number_format($prezzo_totale * 0.01 * $aliquota_iva, 2, '.', '');

        $adb = PearDatabase::getInstance();
        $sql = "select fevatnature from vtiger_products where productid = \"".$productId."\"";
        $res = $adb->pquery($sql, array());
        #var_dump($res);
        $fevatnature = "";
        for ($i = 0; $i < $adb->num_rows($res); $i++) {
            $fevatnature = $adb->query_result($res, $i, "fevatnature");
            $fevatnature = explode(" -", $fevatnature)[0];
        }

        # REQUIRED & N-ABLE{1-inf}
        $xml .= "<DettaglioLinee>\n";
        # REQUIRED::[0-9]{,4}
        $xml .= "<NumeroLinea>{$n_line}</NumeroLinea>\n";
        # ::[:alnum:]{2}
        #$xml .= "<TipoCessionePrestazione></TipoCessionePrestazione>"; # SC -> sconto ; PR -> premio ; AB -> abbuono ; AC -> spesa accessoria
        # N-ABLE{0-inf}
        #$xml .= "<CodiceArticolo>";
        # @ifrequired::[:alnum:]{,35}
        #$xml .= "<CodiceTipo></CodiceTipo>";
        # @ifrequired::[:alnum:]{,35}
        #$xml .= "<CodiceValore></CodiceValore>";
        #$xml .= "</CodiceArticolo>";
        # REQUIRED::[:alnum:]{,1000}
        #$xml .= "<Descrizione><![CDATA[".str_replace(array('<br>', '<br/>', '<br />'), ' ', $productName)."]]></Descrizione>\n";
        #$xml .= "<Descrizione><![CDATA[".str_replace(array('<br>', '<br/>', '<br />'), ' ', htmlspecialchars($invoice_vet["cf_1345"], ENT_DISALLOWED ))."]]></Descrizione>\n";
				#$xml .= "<Descrizione><![CDATA[".str_replace(array("&amp;lt;br /&amp;gt;"," ","&amp;lt;br /&amp;gt;"), ' ', htmlspecialchars($invoice_vet["cf_1345"]))."]]></Descrizione>\n";
				#$xml .= "<Descrizione>".str_replace(array("&amp;lt;br /&amp;gt;","","&amp;lt;br /&amp;gt;"), ' ', htmlspecialchars($invoice_vet["cf_1345"], ENT_SUBSTITUTE))."</Descrizione>\n";
				$xml .= "<Descrizione>".str_replace(array("<br/>","<br>","<br />","’"), array(" ", " ", " ", "'"), html_entity_decode($invoice_vet["cf_1345"], ENT_QUOTES))."</Descrizione>\n";


        #if ( ! empty( $dettaglio_UnitaMisura ) ) {
            # ::[0-9.]{4,21}
            $xml .= "<Quantita>{$quantity}</Quantita>\n";
            # ::[:alnum:]{,10}
        #    $xml .= "<UnitaMisura>{$dettaglio_UnitaMisura}</UnitaMisura>\n";
        #}
        # ::ISO 8601:2004 (YYYY-MM-DD)
        #$xml .= "<DataInizioPeriodo></DataInizioPeriodo>";
        # ::ISO 8601:2004 (YYYY-MM-DD)
        #$xml .= "<DataFinePeriodo></DataFinePeriodo>";
        # REQUIRED::[0-9.]{4,21}
        $xml .= "<PrezzoUnitario>".number_format($price, 2, ".", "")."</PrezzoUnitario>\n";
        #if ($bool_RiferimentoSconto) {
        # N-ABLE{0-inf}
        #	$xml .= "<ScontoMaggiorazione>\n";
        # @ifrequired::[:alnum:]{2}
        #		$xml .= "<Tipo>{$fattura_ScontoMaggiorazioneTipo}</Tipo>\n"; # SC -> sconto ; MG -> maggiorazione
        # ::[0-9]{4,6}
        #$xml .= "<Percentuale></Percentuale>";
        # ::[0-9.]{4,15}
        #		$xml .= "<Importo>{$fattura_ScontoMaggiorazioneValore}</Importo>\n";
        #	$xml .= "</ScontoMaggiorazione>\n";
        #}
        # REQUIRED::[0-9.]{4,21}
        $xml .= "<PrezzoTotale>{$prezzo_totale}</PrezzoTotale>\n";
        # REQUIRED::[0-9.]{4,6}
        $xml .= "<AliquotaIVA>".number_format($aliquota_iva, 2, '.', '')."</AliquotaIVA>\n";





        # ::[:alnum:]{2}
        $ritenuta = 'NO';
        if($invoice_vet["cf_1361"]=='1') $ritenuta = 'SI';
        $xml .= "<Ritenuta>".$ritenuta."</Ritenuta>\n"; # SI -> linea di fattura soggetta a ritenuta
        $aliquota_iva = floatval($aliquota_iva);
        if($aliquota_iva == 0 && !empty($fevatnature)){
        # ::[:alnum:]{2}
            $xml .= "<Natura>{$fevatnature}</Natura>\n"; # {N1 ~ N7} ; v. doc. p. 65
        }
        # ::[:alnum:]{,20}
        #$xml .= "<RiferimentoAmministrazione></RiferimentoAmministrazione>";
        # N-ABLE{0-inf}
        #$xml .= "<AltriDatiGestionali>";
        # @ifrequired::[:alnum:]{,10}
        #$xml .= "<TipoDato></TipoDato>";
        # ::[:alnum:]{,60}
        #$xml .= "<RiferimentoTesto></RiferimentoTesto>";
        # ::[0-9.]{4,21}
        #$xml .= "<RiferimentoNumero></RiferimentoNumero>";
        # ::ISO 8601:2004 (YYYY-MM-DD)
        #$xml .= "<RiferimentoData></RiferimentoData>";
        #$xml .= "</AltriDatiGestionali>";
        $xml .= "</DettaglioLinee>\n";
        $n_line ++;
	}
#print_r($fattura); die();
	#if ( count( $array_iva ) > 1 ) {
		foreach ( $array_iva as $aliquota => $dettaglio_iva ) {
			# Formatted fields
            $totale_imponibile = number_format($dettaglio_iva['imponibile'], 2, '.', '');
            $totale_imposta = number_format($dettaglio_iva['euro_iva'], 2, '.', '');

			# REQUIRED & N-ABLE{1-inf}
			$xml .= "<DatiRiepilogo>\n";
			# REQUIRED::[0-9.]{4,6}
			$xml .= "<AliquotaIVA>{$aliquota_iva}</AliquotaIVA>\n";
			# ::[:alnum:]{2}
			#$xml .= "<Natura></Natura>"; # {N1 ~ N7} ; v. doc. p. 67
			# ::[0-9.]{4,15}
			#$xml .= "<SpeseAccessorie></SpeseAccessorie>";
			# ::[0-9.]{4,21}
			#$xml .= "<Arrotondamento>{$arrotondamento_calculated}</Arrotondamento>\n";
			# REQUIRED::[0-9.]{4,15}
			$xml .= "<ImponibileImporto>{$totale_imponibile}</ImponibileImporto>\n";
			# REQUIRED::[0-9.]{4,15}
			$xml .= "<Imposta>{$totale_imposta}</Imposta>\n";
			# ::[:alnum:]{1}
			$xml .= "<EsigibilitaIVA>{$vat_type}</EsigibilitaIVA>\n"; # I -> IVA ad esigibilita' immediata ; D -> IVA ad esigibilita' differita ; S -> scissione dei pagamenti
			# ::[:alnum:]{,100}
			#$xml .= "<RiferimentoNormativo></RiferimentoNormativo>";
			$xml .= "</DatiRiepilogo>\n";
		}
	/*} else {
		$max_aliquota_iva_calculated  = number_format( $max_aliquota_iva[ $riferimento_iva ], 2, '.', '' );
		$totale_imponibile_calculated = number_format( $values['fattura_ImponibileImporto'], 2, '.', '' );
		$totale_imposta_calculated    = number_format( $values['fattura_Imposta'], 2, '.', '' );
		$arrotondamento_calculated    = number_format( $totale_imponibile_calculated - $arrotondamento[ $riferimento_iva ], 2, '.', '' );

		# REQUIRED & N-ABLE{1-inf}
		$xml .= "<DatiRiepilogo>\n";
		# REQUIRED::[0-9.]{4,6}
		$xml .= "<AliquotaIVA>{$max_aliquota_iva_calculated}</AliquotaIVA>\n";
		# ::[:alnum:]{2}
		#$xml .= "<Natura></Natura>"; # {N1 ~ N7} ; v. doc. p. 67
		# ::[0-9.]{4,15}
		#$xml .= "<SpeseAccessorie></SpeseAccessorie>";
		# ::[0-9.]{4,21}
		$xml .= "<Arrotondamento>{$arrotondamento_calculated}</Arrotondamento>\n";
		# REQUIRED::[0-9.]{4,15}
		$xml .= "<ImponibileImporto>{$totale_imponibile_calculated}</ImponibileImporto>\n";
		# REQUIRED::[0-9.]{4,15}
		$xml .= "<Imposta>{$totale_imposta_calculated}</Imposta>\n";
		# ::[:alnum:]{1}
		$xml .= "<EsigibilitaIVA>{$values['fattura_EsigibilitaIVA']}</EsigibilitaIVA>\n"; # I -> IVA ad esigibilita' immediata ; D -> IVA ad esigibilita' differita ; S -> scissione dei pagamenti
		# ::[:alnum:]{,100}
		#$xml .= "<RiferimentoNormativo></RiferimentoNormativo>";
		$xml .= "</DatiRiepilogo>\n";
	}*/
	$xml .= "</DatiBeniServizi>\n";

	#$xml .= "<DatiVeicoli>";
	# @ifrequired::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<Data></Data>";
	# @ifrequired::[:alnum:]{,15}
	#$xml .= "<TotalePercorso></TotalePercorso>";
	#$xml .= "</DatiVeicoli>";

	# N-ABLE{0-inf}
	$xml .= "<DatiPagamento>\n";
	# @ifrequired::[:alnum:]{4}
	$xml .= "<CondizioniPagamento>{$condizioni_pagamento}</CondizioniPagamento>\n"; # TP01 -> pagamento a rate ; TP02 -> pagamento completo ; TP03 -> anticipo
	# @ifrequired & N-ABLE{1-inf}
	$xml .= "<DettaglioPagamento>\n";
	# ::[:alnum:]{,200}
	#$xml .= "<Beneficiario></Beneficiario>";
	# @ifrequired::[:alnum:]{4}
	$xml .= "<ModalitaPagamento>{$codice_pagamento}</ModalitaPagamento>\n"; # {MP01 ~ MP22} ; v. doc. p. 70-71
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataRiferimentoTerminiPagamento></DataRiferimentoTerminiPagamento>";
	# ::[0-9]{3}
	#$xml .= "<GiorniTerminiPagamento></GiorniTerminiPagamento>"; # 0 -> pagamento a vista
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataScadenzaPagamento></DataScadenzaPagamento>";
	# @ifrequired::[0-9.]{4,15}
	$xml .= "<ImportoPagamento>".number_format($totale,2,".","")."</ImportoPagamento>\n";
	# ::[:alnum:]{,20}
	#$xml .= "<CodUfficioPostale></CodUfficioPostale>";
	# ::[:alnum:]{,60}
	#$xml .= "<CognomeQuietanzante></CognomeQuietanzante>";
	# ::[:alnum:]{,60}
	#$xml .= "<NomeQuietanzante></NomeQuietanzante>";
	# ::[:alnum:]{16}
	#$xml .= "<CFQuietanzante></CFQuietanzante>";
	# ::[:alnum:]{2,10}
	#$xml .= "<TitoloQuietanzante></TitoloQuietanzante>";
	# ::[:alnum:]{,80}
	$xml .= "<IstitutoFinanziario>{$banca}</IstitutoFinanziario>\n";
	# ::[:alnum:]{15,34}
	$xml .= "<IBAN>{$iban}</IBAN>\n";
	# ::[0-9]{5}
	#$xml .= "<ABI></ABI>";
	# ::[0-9]{5}
	#$xml .= "<CAB></CAB>";
	# ::[:alnum:]{8,11}
	#$xml .= "<BIC></BIC>";
	# ::[0-9.]{4,15}
	#$xml .= "<ScontoPagamentoAnticipato></ScontoPagamentoAnticipato>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataLimitePagamentoAnticipato></DataLimitePagamentoAnticipato>";
	# ::[0-9.]{4,15}
	#$xml .= "<PenalitaPagamentiRitardati></PenalitaPagamentiRitardati>";
	# ::ISO 8601:2004 (YYYY-MM-DD)
	#$xml .= "<DataDecorrenzaPenale></DataDecorrenzaPenale>";
	# ::[:alnum:]{,60}
	#$xml .= "<CodicePagamento></CodicePagamento>";
	$xml .= "</DettaglioPagamento>\n";
	$xml .= "</DatiPagamento>\n";

	# N-ABLE{0-inf}
	#$xml .= "<Allegati>";
	# @ifrequired::[:alnum:]{,60}
	#$xml .= "<NomeAttachment></NomeAttachment>";
	# ::[:alnum:]{,10}
	#$xml .= "<AlgoritmoCompressione></AlgoritmoCompressione>";
	# ::[:alnum:]{,10}
	#$xml .= "<FormatoAttachment></FormatoAttachment>";
	# ::[:alnum:]{,100}
	#$xml .= "<DescrizioneAttachment></DescrizioneAttachment>";
	# @ifrequired::xs:base64Binary
	#$xml .= "<Attachment></Attachment>";
	#$xml .= "</Allegati>";

	# /body
	$xml .= "</FatturaElettronicaBody>\n";


	# /xml
	$xml .= "</p:FatturaElettronica>";

		return $xml;
}

function getFolders() {

	$fieldvalue= array();

	$adb = PearDatabase::getInstance();
	$sql = "select foldername,folderid from vtiger_attachmentsfolder order by foldername";
        $res = $adb->pquery($sql, array());
        for ($i = 0; $i < $adb->num_rows($res); $i++) {
            $fid = $adb->query_result($res, $i, "folderid");
            $fname = $adb->query_result($res, $i, "foldername");
            $fieldvalue[$fid] =  $fname;
        }
        return $fieldvalue;
}

function save_file($doc, $docsize, $fileName) {
	try {
		$db = PearDatabase::getInstance();
		$currentUserModel = Users_Record_Model::getCurrentUserModel();
		$uploadPath = decideFilePath();



		$attachid = $db->getUniqueId('vtiger_crmentity');
		$binFile = sanitizeUploadFileName($fileName, vglobal('upload_badext'));
		$fileName = ltrim(basename(" ".$binFile));
#echo $uploadPath.$attachid."_".$fileName; die();
		if (file_put_contents($uploadPath.$attachid."_".$fileName, $doc) > 0) {
			$description = $fileName;
			$date_var = $db->formatDate(date('YmdHis'), true);
			$usetime = $db->formatDate($date_var, true);

			$db->pquery("INSERT INTO vtiger_crmentity(crmid, smcreatorid, smownerid,
				modifiedby, setype, description, createdtime, modifiedtime, presence, deleted)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
				Array($attachid, $currentUserModel->getId(), $currentUserModel->getId(), $currentUserModel->getId(), "Documents Attachment", $description, $usetime, $usetime, 1, 0));

			$mimetype  = "application/xml";

			echo "$mimetype";

			$db->pquery("INSERT INTO vtiger_attachments SET attachmentsid=?, name=?, description=?, type=?, path=?",
				Array($attachid, $fileName, $description, $mimetype, $uploadPath));

			$document = CRMEntity::getInstance("Documents");
			$document->column_fields['notes_title'] = "$fileName";
			$document->column_fields['filename'] = $fileName;
			$document->column_fields['notecontent'] = "DA CLI";
			$document->column_fields['filesize'] = $docsize; //filesize($fileName);
			$document->column_fields['filetype'] = "application/xml";
			$document->column_fields['fileversion'] = '';
			$document->column_fields['filestatus'] = 1;
			$document->column_fields['filelocationtype'] = 'I';
			$document->column_fields['folderid'] = 1; // Default Folder
			$document->column_fields['assigned_user_id'] = 1;
			$document->column_fields['filestatus'] = 1;
			$document->save('Documents');

			$db->pquery("INSERT INTO vtiger_seattachmentsrel(crmid, attachmentsid) VALUES(?,?)",
				Array($document->id, $attachid));
			return $document;

		}
		return null;
	} catch (Exception $e) {
		echo $e->getMessage();
	}
}
