<?php
/**************************************************************************************
 *	Copyright (C) 2019  Simone Macrì
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : FatturaElettronica
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1, 7.1.0
 *  Author              : Simone Macrì - web: www.antworks.it - email: simone.macri@antworks.it
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

$config = Array();
$config['iban'] = "IBAN: IT....";
$config['metodopagamento'] = "Banca Popolare.....";
$config['mapping']['org']['partitaiva'] = "01687650992";
$config['mapping']['org']['codicefiscale'] = "01687650992";
$config['mapping']['org']['provinciaconsegna'] = "GE";
$config['mapping']['org']['provinciafatturazione'] = "GE";

// true, if you want invoices to be sent by email, otherwise put: false
$config['send_email'] = true;

// true, if you want the tests and submissions to the Fattura24 API to be ignored,
// and to have a var_dump () of the variables.
$config['debug'] = true;
// false, if you want to disable the 'header("Location: ...")', of the functions
$config['debugLocation'] = true;

$config['fields'] = [
	"name" => [
		"accountname",
		"firstname"
	],
	"surname" => [
		"lastname",
		"cf_1043"
		],

	"street" => [
		"ship_street",
		"cf_751"
	],
	"ship_street" => [
		"ship_street"
	],
	"postal_code" => [
		"bill_code",
		"mailingzip",
        "cf_757",
        "cf_797"
	],
	"ship_postal_code" => [
		"ship_code"
	],
	"city" => [
		"ship_city"
	],
	"ship_city" => [
		"bill_city"
	],
	"state" => [
		"bill_state",
		"mailingstate",
		"cf_759"
	],
	"ship_state" => [
		"ship_state"
	],
	"country" => [
		"bill_country",
		"mailingcountry",
	],
	"ship_country" => [
		"ship_country"
	],
	"fiscal_code" => [
		"cf_856"
	],
	"vat_number" => [
		"cf_854"
	],
	"phone" => [
		"phone",
		"mobile",
		"homephone",
		"otherphone"
	],
	"email" => [
		"email",
		"email1",
		"secondaryemail"
	],
	"provincia" => [
        "bill_state",
        "ship_state"
	],
	"provincia_consegna" => [
		"ship_state"
	],
	"provincia_fatturazione" => [
		"bill_state"
	],
	"vat_type" => [
		"vattype"
	],
	"fe_customer_pec" => [
		"cf_858",
	    "email"
	],
	"fe_destination_code" => [
		"siccode"
	],
    "invoice_date" => [
        "invoicedate"
    ],
    "invoice_no" => [
        "invoice_no"
    ],
    "iban" => [
        "cf_1183"
    ],
    "codice_pagamento" => [
        "fepaymentcode"
    ],
    "condizioni_pagamento" => [
        "cf_1185"
    ],
		"banca" => [
				"cf_1349"
		],

];
