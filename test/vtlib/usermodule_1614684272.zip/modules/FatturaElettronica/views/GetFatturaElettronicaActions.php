<?php
/**************************************************************************************
 *	Copyright (C) 2019  Simone Macrì
 *		This program is free software; you can redistribute it and/or modify
 *		it under the terms of the GNU General Public License as published by
 *		the Free Software Foundation; either version 3 of the License, or any later version.
 *
 *  Module              : FatturaElettronica
 *  Version             : 1.0.0-BETA
 *  Vtiger              : 7.0.0, 7.0.1, 7.1.0
 *  Author              : Simone Macrì - web: www.antworks.it - email: simone.macri@antworks.it
 *  Supported browsers  : Internet Explorer 7 or higher, Mozilla Firefox 3.0 or higher
 *  Licenza             : GPLv3 - https://opensource.org/licenses/GPL-3.0
 ***************************************************************************************/

class Fattura24_GetFattura24ctions_View extends Vtiger_BasicAjax_View {
	public function process(Vtiger_Request $request) {
		$viewer = $this->getViewer($request);
		$viewer->view("SideBar.tpl", 'Fattura24');
	}
}
